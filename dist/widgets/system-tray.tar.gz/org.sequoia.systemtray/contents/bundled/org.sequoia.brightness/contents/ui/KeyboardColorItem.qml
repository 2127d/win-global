/*
 * SPDX-FileCopyrightText: 2024 Natalie Clarius <natalie.clarius@kde.org>
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

import QtQuick
import "../details" as Details
import QtQuick.Layouts

import org.kde.plasma.components as PlasmaComponents3
import org.kde.kirigami as Kirigami

import org.kde.plasma.private.brightnesscontrolplugin

Details.DetailDelegate {
    id: root

    background.visible: true
    highlighted: activeFocus
    hoverEnabled: false

    visible: keyboardColorControl.supported

    Accessible.onPressAction: syncAccentSwitch.click()
    Keys.onSpacePressed: syncAccentSwitch.click()

    KeyboardColorControl {
        id: keyboardColorControl
    }

    contentItem: RowLayout {
        spacing: Kirigami.Units.gridUnit

        Kirigami.Icon {
            id: image
            Layout.alignment: Qt.AlignTop
            Layout.preferredWidth: Kirigami.Units.iconSizes.medium
            Layout.preferredHeight: Kirigami.Units.iconSizes.medium
            source: "input-keyboard-color"
        }

        ColumnLayout {
            Layout.fillWidth: true
            Layout.alignment: Qt.AlignTop
            spacing: Kirigami.Units.smallSpacing

            RowLayout {
                Layout.fillWidth: true
                spacing: Kirigami.Units.smallSpacing

                PlasmaComponents3.Label {
                    id: title
                    text: root.text
                    textFormat: Text.PlainText

                    elide: Text.ElideRight
                    Layout.fillWidth: true
                }

                Rectangle {
                    id: colorIndicator

                    implicitWidth: Math.round(Kirigami.Units.gridUnit * 1.25)
                    implicitHeight: Math.round(Kirigami.Units.gridUnit * 1.25)
                    radius: 180

                    color: keyboardColorControl.enabled ? Kirigami.Theme.highlightColor : "transparent"
                    border.color: Qt.rgba(0, 0, 0, 0.15)
                }
            }

            RowLayout {
                PlasmaComponents3.Switch {
                    id: syncAccentSwitch
                    checked: keyboardColorControl.enabled
                    text: i18n("Follow accent color")

                    Layout.fillWidth: true

                    activeFocusOnTab: false
                    focusPolicy: Qt.NoFocus

                    onClicked: {
                        keyboardColorControl.enabled = checked;
                    }
                }
            }
        }
    }
}

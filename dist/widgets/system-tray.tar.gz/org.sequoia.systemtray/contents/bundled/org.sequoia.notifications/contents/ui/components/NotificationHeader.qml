/*
    SPDX-FileCopyrightText: 2018-2019 Kai Uwe Broulik <kde@privat.broulik.de>
    SPDX-FileCopyrightText: 2024 Marco Martin <mart@kde.org>

    SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL
*/

import QtQuick
import QtQuick.Layouts

import org.kde.kirigami as Kirigami

RowLayout {
    id: notificationHeading

    property ModelInterface modelInterface: ModelInterface {}
    property alias closeButtonTooltip: headingButtons.closeButtonTooltip

    spacing: 8

    Kirigami.Icon {
        id: applicationIconItem
        Layout.preferredWidth: 24
        Layout.preferredHeight: 24
        source: notificationHeading.modelInterface.applicationIconSource
        visible: valid
    }

    Kirigami.Heading {
        id: applicationNameLabel
        Layout.fillWidth: true
        level: 5
        opacity: 1
        font.family: Kirigami.Theme.smallFont.family
        font.pointSize: Kirigami.Theme.smallFont.pointSize
        font.weight: Font.Medium
        color: Kirigami.Theme.disabledTextColor
        textFormat: Text.PlainText
        elide: Text.ElideMiddle
        maximumLineCount: 2
        text: notificationHeading.modelInterface.applicationName + (notificationHeading.modelInterface.originName ? " · " + notificationHeading.modelInterface.originName : "")
    }
    HeadingButtons {
        id: headingButtons
        modelInterface: notificationHeading.modelInterface
    }
}

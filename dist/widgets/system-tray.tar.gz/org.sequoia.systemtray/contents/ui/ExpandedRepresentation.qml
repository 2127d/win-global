/*
    SPDX-FileCopyrightText: 2016 Marco Martin <mart@kde.org>
    SPDX-FileCopyrightText: 2020 Nate Graham <nate@kde.org>

    SPDX-License-Identifier: LGPL-2.0-or-later
*/
pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Layouts
import QtQuick.Window
import "../details" as Details
import org.kde.kitemmodels as KItemModels

import org.kde.kirigami as Kirigami
import org.kde.plasma.components as PlasmaComponents
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.extras as PlasmaExtras
import org.kde.plasma.plasmoid

Item {
    id: popup
    objectName: "sequoiaControlCenter"
    property bool showAllItems: false
    ControlBackend { id: controls }
    ControlItems {
        id: trayItems
        objectName: "controlCenterItems"
        configuration: Plasmoid.configuration
        sourceModel: Plasmoid.systemTrayModel
    }
    function goHome() {
        systemTrayState.setActiveApplet(null);
        showAllItems = false;
    }
    function openApplet(plugin) {
        const model = Plasmoid.systemTrayModel;
        const role = model.KItemModels.KRoleNames.role("applet");
        for (let row = 0; row < model.rowCount(); ++row) {
            const applet = model.data(model.index(row, 0), role);
            if (applet && applet.Plasmoid.pluginName === plugin) {
                systemTrayState.setActiveApplet(applet, row);
                return;
            }
        }
        goHome();
    }
    Connections {
        target: systemTrayState
        function onExpandedChanged() {
            if (!systemTrayState.expanded) popup.showAllItems = false;
        }
    }

    readonly property bool compactDashboard: !systemTrayState.activeApplet && !showAllItems
    readonly property bool weatherPage: systemTrayState.activeApplet?.Plasmoid.pluginName === "org.sequoia.weather"
    readonly property real dashboardWidth: Math.max(1, Math.min(1600, Math.max(260, Plasmoid.configuration.controlCenterWidth ?? 297), Screen.width - 60))
    readonly property real dashboardHeight: Math.max(1, Math.min(1600, Math.max(240, Plasmoid.configuration.controlCenterHeight ?? 451), Screen.height - 60))
    onCompactDashboardChanged: {
        if (!compactDashboard) Qt.callLater(function() {
            if (popup.compactDashboard) return;
            // AppletPopup retains the previous window size when its maximum
            // is released. Restore the detail size from the original dashboard,
            // after the detail page's minimum sizes have taken effect.
            dialog.width = popup.Layout.preferredWidth + dialog.leftPadding + dialog.rightPadding;
            dialog.height = Math.max(popup.Layout.preferredHeight, Math.min(451, Screen.height - 60))
                + dialog.topPadding + dialog.bottomPadding;
        });
    }
    Layout.minimumWidth: compactDashboard ? dashboardWidth : weatherPage ? Math.min(520, Screen.width - 60) : Kirigami.Units.gridUnit * 24
    Layout.preferredWidth: Layout.minimumWidth
    Layout.maximumWidth: compactDashboard ? dashboardWidth : Infinity
    Layout.minimumHeight: compactDashboard ? dashboardHeight : weatherPage ? Math.min(640, Screen.height - 100) : Kirigami.Units.gridUnit * 24
    Layout.preferredHeight: Layout.minimumHeight
    Layout.maximumHeight: compactDashboard ? Layout.minimumHeight : Infinity

    property alias hiddenLayout: hiddenItemsView.layout
    property alias plasmoidContainer: container

    // Header
    PlasmaExtras.PlasmoidHeading {
        id: plasmoidHeading
        anchors {
            top: parent.top
            left: parent.left
            right: parent.right
        }
        height: trayHeading.height + 8
        topInset: 0
        bottomInset: 0
        leftInset: container.visible ? container.Layout.leftMargin : dashboard.Layout.leftMargin
        rightInset: container.visible ? container.Layout.rightMargin : dashboard.Layout.rightMargin
        background: Details.DetailSurface { radius: 10; elevated: true }
        Behavior on height {
            NumberAnimation { duration: Kirigami.Units.shortDuration / 2; easing.type: Easing.InOutQuad }
        }
    }

    // Main content layout
    ColumnLayout {
        id: expandedRepresentation
        anchors.fill: parent
        // TODO: remove this so the scrollview fully touches the header;
        // add top padding internally
        spacing: 8

        // Header content layout
        RowLayout {
            id: trayHeading
            // A taller applet must not stretch the shared header row.
            Layout.fillHeight: false
            Layout.maximumHeight: implicitHeight
            Layout.topMargin: 4
            Layout.leftMargin: plasmoidHeading.leftInset + 6
            Layout.rightMargin: plasmoidHeading.rightInset + 6
            Layout.bottomMargin: 4
            spacing: 6
            Layout.fillWidth: true

            ControlHeaderButton {
                id: backButton
                visible: !!systemTrayState.activeApplet || popup.showAllItems
                icon.name: mirrored ? "go-previous-symbolic-rtl" : "go-previous-symbolic"

                display: PlasmaComponents.AbstractButton.IconOnly
                text: i18nc("@action:button", "Go Back")

                KeyNavigation.down: hiddenItemsView.visible ? popup.hiddenLayout : container

                onClicked: if (typeof systemTrayState.activeApplet?.backAction !== "undefined" && systemTrayState.activeApplet.backAction.enabled) {
                    systemTrayState.activeApplet?.backAction.trigger()
                } else {
                    popup.goHome()
                }
            }

            Kirigami.Heading {
                Layout.fillWidth: true
                leftPadding: backButton.visible ? 0 : Kirigami.Units.largeSpacing

                level: 2
                font.weight: Font.DemiBold
                Layout.fillHeight: true
                verticalAlignment: Text.AlignVCenter
                topPadding: 0
                bottomPadding: 0
                text: systemTrayState.activeApplet ? systemTrayState.activeApplet.plasmoid.title : (popup.showAllItems ? i18n("More tray items") : i18n("Control Center"))
                maximumLineCount: 1
                textFormat: Text.PlainText
                elide: Text.ElideRight
            }

            Repeater {
                id: primaryActionButtons

                model: {
                    if (actionsButton.applet === null) {
                        return [];
                    }
                    return actionsButton.applet.Plasmoid.contextualActions.filter(action => {
                        return !action.isSeparator && action.priority === PlasmaCore.Action.HighPriority;
                    });
                }

                delegate: ControlHeaderButton {
                    id: actionButton
                    required property int index
                    required property PlasmaCore.Action modelData
                    // We cannot use `action` as it is already a QQuickAction property of the button
                    property PlasmaCore.Action qAction: modelData

                    visible: qAction && qAction.visible

                    // NOTE: it needs an IconItem because QtQuickControls2 buttons cannot load QIcons as their icon
                    contentItem: Kirigami.Icon {
                        anchors.centerIn: parent
                        active: actionButton.hovered
                        implicitWidth: 18
                        implicitHeight: implicitWidth
                        source: actionButton.qAction ? actionButton.qAction.icon.name : ""
                    }

                    enabled: qAction && qAction.enabled
                    checkable: qAction && qAction.checkable
                    checked: qAction && qAction.checked
                    display: PlasmaComponents.AbstractButton.IconOnly
                    text: qAction ? qAction.text : ""

                    KeyNavigation.down: backButton.KeyNavigation.down
                    KeyNavigation.left: (index > 0) ? primaryActionButtons.itemAt(index - 1) : backButton
                    KeyNavigation.right: (index < primaryActionButtons.count - 1) ? primaryActionButtons.itemAt(index + 1) :
                                                            actionsButton.visible ? actionsButton : actionsButton.KeyNavigation.right

                    PlasmaComponents.ToolTip {
                        text: actionButton.text
                    }

                    onClicked: {
                        if (qAction) {
                            qAction.trigger();
                        }
                    }
                }
            }

            ControlHeaderButton {
                id: actionsButton
                visible: visibleActions > 0
                enabled: showAsMenu || (singleAction && singleAction.enabled)
                checked: showAsMenu ? configMenu.status !== PlasmaExtras.Menu.Closed : singleAction && singleAction.checked

                property QtObject applet: systemTrayState.activeApplet || root
                property int visibleActions: actions.length
                property PlasmaCore.Action singleAction: visibleActions === 1 && menuItemFactory.object ? menuItemFactory.object.action : null
                property bool showAsMenu: visibleActions > 1 || (singleAction !== null && singleAction.alwaysShowAsMenu === true)

                readonly property var actions: {
                    if (!applet) {
                        return [];
                    }

                    return applet.plasmoid.contextualActions
                        .filter(action => {
                            return action.visible &&
                            action.priority === PlasmaCore.Action.NormalPriority &&
                            action !== applet.plasmoid.internalAction("configure");
                        })
                        // squash separators
                        .reduce((dstActions, action, i, srcActions) => {
                            if (!action.isSeparator) {
                                const prevAction = srcActions[i - 1];
                                if (prevAction?.isSeparator && dstActions.length > 0) {
                                    dstActions.push(prevAction);
                                }
                                dstActions.push(action);
                            }
                            return dstActions;
                        }, []);
                }

                icon.name: "application-menu"
                checkable: showAsMenu || (singleAction && singleAction.checkable)
                contentItem.opacity: showAsMenu

                display: PlasmaComponents.AbstractButton.IconOnly
                text: (actionsButton.singleAction && !showAsMenu) ? actionsButton.singleAction.text: i18n("More actions")

                Accessible.role: (singleAction && !showAsMenu) ? Accessible.Button : Accessible.ButtonMenu
                KeyNavigation.down: backButton.KeyNavigation.down
                KeyNavigation.right: configureButton.visible ? configureButton : configureButton.KeyNavigation.right

                // NOTE: it needs a Kirigami.Icon because QtQuickControls2 buttons cannot load QIcons as their icon
                Kirigami.Icon {
                    parent: actionsButton
                    anchors.centerIn: parent
                    active: actionsButton.hovered
                    implicitWidth: 18
                    implicitHeight: implicitWidth
                    source: (actionsButton.singleAction && !actionsButton.showAsMenu) ? actionsButton.singleAction.icon.name : ""
                    visible: actionsButton.singleAction && !actionsButton.showAsMenu
                }
                onToggled: {
                    if (showAsMenu) {
                        if (checked) {
                            configMenu.openRelative();
                        } else {
                            configMenu.close();
                        }
                    }
                }
                onClicked: {
                    if (singleAction && !showAsMenu) {
                        singleAction.trigger();
                    }
                }
                PlasmaComponents.ToolTip {
                    text: actionsButton.text
                }
                PlasmaExtras.Menu {
                    id: configMenu
                    visualParent: actionsButton
                    placement: PlasmaExtras.Menu.BottomPosedLeftAlignedPopup
                }

                Instantiator {
                    id: menuItemFactory

                    model: actionsButton.actions

                    delegate: PlasmaExtras.MenuItem {
                        id: menuItem
                        required property PlasmaCore.Action modelData
                        action: modelData
                    }

                    onObjectAdded: (index, object) => {
                        configMenu.addMenuItem(object);
                    }

                    onObjectRemoved: (index, object) => {
                        configMenu.removeMenuItem(object)
                    }
                }
            }
            ControlHeaderButton {
                id: configureButton
                icon.name: "configure"
                visible: actionsButton.applet && actionsButton.applet.plasmoid.internalAction("configure")

                display: PlasmaComponents.AbstractButton.IconOnly
                text: actionsButton.applet?.plasmoid.internalAction("configure")?.text ?? ""

                KeyNavigation.down: backButton.KeyNavigation.down
                KeyNavigation.left: actionsButton.visible ? actionsButton : actionsButton.KeyNavigation.left
                KeyNavigation.right: pinButton

                PlasmaComponents.ToolTip {
                    text: parent.visible ? parent.text : ""
                }
                onClicked: actionsButton.applet.plasmoid.internalAction("configure").trigger();
            }

            ControlHeaderButton {
                id: pinButton
                checkable: true
                checked: Plasmoid.configuration.pin
                onToggled: Plasmoid.configuration.pin = checked
                icon.name: "window-pin"

                display: PlasmaComponents.AbstractButton.IconOnly
                text: i18n("Keep Open")

                KeyNavigation.down: backButton.KeyNavigation.down
                KeyNavigation.left: configureButton.visible ? configureButton : configureButton.KeyNavigation.left
                KeyNavigation.tab: hiddenItemsView.visible ? hiddenItemsView.layout : container.currentItem?.nextItemInFocusChain() ?? null

                PlasmaComponents.ToolTip {
                    text: parent.text
                }
            }
        }

        ControlDashboard {
            id: dashboard
            backend: controls
            customItems: trayItems.customItems
            otherItems: trayItems.otherItems
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.margins: Kirigami.Units.smallSpacing
            visible: !systemTrayState.activeApplet && !popup.showAllItems
            onOpenApplet: plugin => popup.openApplet(plugin)
        }

        // Grid view of all available items
        HiddenItemsView {
            id: hiddenItemsView
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.topMargin: Kirigami.Units.smallSpacing
            visible: !systemTrayState.activeApplet && popup.showAllItems

            KeyNavigation.up: pinButton

            onVisibleChanged: {
                if (visible) {
                    layout.forceActiveFocus();
                    systemTrayState.oldVisualIndex = systemTrayState.newVisualIndex = -1;
                }
            }
        }

        // Container for currently visible item
        PlasmoidPopupsContainer {
            id: container
            Layout.fillWidth: true
            Layout.fillHeight: true
            visible: systemTrayState.activeApplet

            // We need to add margin on the top so it matches the dialog's own margin
            Layout.topMargin: 0
            Layout.margins: 4

            KeyNavigation.up: pinButton
            KeyNavigation.backtab: pinButton

            onVisibleChanged: {
                if (visible) {
                    forceActiveFocus();
                }
            }
        }
    }

    // Footer
    PlasmaExtras.PlasmoidHeading {
        id: plasmoidFooter
        position: PlasmaComponents.ToolBar.Footer
        anchors {
            bottom: parent.bottom
            left: parent.left
            right: parent.right
        }
        visible: false // Detail pages own their inset footer surfaces.
        height: container.footerHeight
        // So that it doesn't appear over the content view, which results in
        // the footer controls being inaccessible
        z: -9999
    }
}

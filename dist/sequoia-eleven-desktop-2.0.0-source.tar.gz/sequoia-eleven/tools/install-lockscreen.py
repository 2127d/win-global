#!/usr/bin/env python3
"""Install the lock-screen appearance override from the current system shell."""
import argparse
import os
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise RuntimeError('The installed Plasma lock screen has changed; review the override before installing.')
    return text.replace(old, new, 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prefix', type=Path,
                        default=Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local/share'))
    args = parser.parse_args()
    source = Path('/usr/share/plasma/shells/org.kde.plasma.desktop')
    destination = args.prefix / 'plasma/shells/org.kde.plasma.desktop'
    marker = destination / '.sequoia-eleven-lockscreen'
    if destination.exists() and not marker.exists():
        raise RuntimeError(f'Refusing to overwrite an existing custom shell: {destination}')
    lockscreen = source / 'contents/lockscreen'
    main_block = replace_once((lockscreen / 'MainBlock.qml').read_text(),
                              'SessionManagementScreen {', 'SequoiaSession {')
    main_block = replace_once(main_block, '    RowLayout {\n        Layout.fillWidth: true', '''    RowLayout {
        Layout.fillWidth: true
        Layout.maximumWidth: 360
        Layout.alignment: Qt.AlignHCenter
        spacing: 6''')
    main_block = replace_once(main_block,
                              '            font.pointSize: Kirigami.Theme.defaultFont.pointSize + 1\n', '')
    main_block = replace_once(main_block, '            id: passwordBox\n', '''            id: passwordBox
            // Preserve typing focus and the normal field; omit focus/hover rings.
            font.pixelSize: 14
            implicitHeight: 36
            Layout.minimumHeight: 36
            Layout.maximumHeight: 36
            color: "#f5f6f8"
            placeholderTextColor: "#b9bcc4"
            Kirigami.Theme.colorSet: Kirigami.Theme.Complementary
            Kirigami.Theme.textColor: "#f5f6f8"
            background: Rectangle {
                implicitWidth: 280
                implicitHeight: 36
                radius: 11
                color: "#25ffffff"
                antialiasing: true
                border.width: 1
                border.color: "#b3ffffff"
                readonly property QtObject margins: QtObject {
                    property real left: 12
                    property real right: 12
                    property real top: 6
                    property real bottom: 6
                }
            }
''')
    main_block = replace_once(main_block, '            id: loginButton\n', '''            id: loginButton
            // Keep the unlock icon and background steady on pointer hover.
            hoverEnabled: false
            Layout.minimumWidth: 36
            Layout.maximumWidth: 36
            Layout.minimumHeight: 36
            Layout.maximumHeight: 36
            icon.width: 20
            icon.height: 20
            padding: 6
            Kirigami.Theme.colorSet: Kirigami.Theme.Complementary
            Kirigami.Theme.textColor: "#f5f6f8"
            background: Rectangle {
                radius: 11
                color: loginButton.down ? "#45ffffff" : "#25ffffff"
                border.color: "#28ffffff"
            }
''')
    screen_ui = replace_once((lockscreen / 'LockScreenUi.qml').read_text(),
                             '                        icon.name: "system-switch-user"\n',
                             '''                        icon.name: "system-switch-user"
                        // Keep the icon and its background steady on pointer hover.
                        hoverEnabled: false
''')
    screen_ui = replace_once(screen_ui, '        Clock {', '        SequoiaClock {')
    screen_ui = screen_ui.replace('                    ActionButton {', '                    SequoiaActionButton {')
    screen_ui = replace_once(screen_ui, '        WallpaperFader {', '        SequoiaWallpaperFader {')
    screen_ui = replace_once(screen_ui,
                             '                    Layout.preferredHeight: item ? item.implicitHeight : 0',
                             '''                    Layout.preferredHeight: item ? item.implicitHeight : 0
                    Layout.maximumWidth: item ? item.implicitWidth : 392
                    Layout.alignment: Qt.AlignHCenter''')
    screen_ui = replace_once(screen_ui, 'height: lockScreenRoot.height + Kirigami.Units.gridUnit * 3',
                             'height: lockScreenRoot.height - Kirigami.Units.gridUnit * 4')
    screen_ui = replace_once(screen_ui, '    Kirigami.Theme.colorSet: Kirigami.Theme.Complementary', '''    Kirigami.Theme.colorSet: Kirigami.Theme.Complementary
    Kirigami.Theme.textColor: "#f2f3f5"
    Kirigami.Theme.backgroundColor: "#252629"''')
    session_source = Path('/usr/lib64/qt6/qml/org/kde/breeze/components')
    session = (session_source / 'SessionManagementScreen.qml').read_text()
    session = session.replace('    UserList {', '    SequoiaUserList {')
    session = session.replace('Kirigami.Units.gridUnit * 16', 'Math.min(root.width - 40, 432)')
    session = session.replace('Kirigami.Units.gridUnit * 10', 'Kirigami.Units.gridUnit * 17')
    session = session.replace('font.italic: true', 'font.italic: false')
    user_list = (session_source / 'UserList.qml').read_text().replace('UserDelegate', 'SequoiaUserDelegate')
    user_list = user_list.replace('gridUnit * 8', 'gridUnit * 10').replace('gridUnit * 9', 'gridUnit * 8.7')
    user_delegate = (session_source / 'UserDelegate.qml').read_text()
    user_delegate = user_delegate.replace('gridUnit * 7', 'gridUnit * 6').replace('wrapper.fontSize + 4', 'wrapper.fontSize + 1')
    user_delegate = user_delegate.replace('anchors.topMargin: Kirigami.Units.gridUnit', 'anchors.topMargin: Kirigami.Units.smallSpacing * 2')
    # Copy the complete shell so its other resources continue to resolve locally.
    # Re-running after Plasma upgrades refreshes these unmodified system files.
    shutil.copytree(source, destination, dirs_exist_ok=True)
    (destination / 'contents/lockscreen/MainBlock.qml').write_text(main_block)
    (destination / 'contents/lockscreen/LockScreenUi.qml').write_text(screen_ui)
    (destination / 'contents/lockscreen/SequoiaSession.qml').write_text(session)
    (destination / 'contents/lockscreen/SequoiaUserList.qml').write_text(user_list)
    (destination / 'contents/lockscreen/SequoiaUserDelegate.qml').write_text(user_delegate)
    no_password = (lockscreen / 'NoPasswordUnlock.qml').read_text().replace('SessionManagementScreen {','SequoiaSession {')
    no_password = no_password.replace('PlasmaComponents3.Button {','SequoiaActionButton {')
    (destination / 'contents/lockscreen/NoPasswordUnlock.qml').write_text(no_password)
    for path in (ROOT / 'lockscreen').glob('*.qml'):
        shutil.copy2(path, destination / 'contents/lockscreen' / path.name)
    marker.write_text('Local appearance override; refresh with tools/install-lockscreen.py after Plasma updates.\n')
    print(f'Installed lock-screen appearance override to {destination}')


if __name__ == '__main__':
    main()

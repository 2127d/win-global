// SPDX-License-Identifier: MIT
// Check that plasmawindowed actually creates the installed applet's QML item.
#include <QCoreApplication>
#include <QGuiApplication>
#include <QQuickItem>
#include <QQuickWindow>
#include <QQmlContext>
#include <QQmlEngine>
#include <QTimer>
#include <cstdio>

static bool containsApplet(QQuickItem *item, const QString &entry)
{
    if (auto context = QQmlEngine::contextForObject(item)) {
        if (context->baseUrl().toLocalFile() == entry && item->isVisible())
            return true;
    }
    for (auto child : item->childItems())
        if (containsApplet(child, entry)) return true;
    return false;
}

static void verify()
{
    auto timer = new QTimer(qApp);
    QObject::connect(timer, &QTimer::timeout, [] {
        const auto entry = qEnvironmentVariable("SEQUOIA_VERIFY_WIDGET_ENTRY");
        for (auto window : QGuiApplication::allWindows()) {
            auto quick = qobject_cast<QQuickWindow *>(window);
            if (quick && containsApplet(quick->contentItem(), entry)) {
                std::fprintf(stdout, "PASS: loaded installed widget %s\n", qPrintable(entry));
                QCoreApplication::exit(0);
                return;
            }
        }
    });
    timer->start(100);
    QTimer::singleShot(8000, [] {
        std::fprintf(stderr, "FAIL: installed widget QML did not become visible\n");
        QCoreApplication::exit(1);
    });
}
Q_COREAPP_STARTUP_FUNCTION(verify)

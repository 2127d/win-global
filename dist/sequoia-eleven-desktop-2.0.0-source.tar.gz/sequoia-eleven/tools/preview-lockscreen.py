#!/usr/bin/env python3
"""Capture the real greeter in offscreen testing mode with sample media."""
import os
import argparse
import configparser
from pathlib import Path
import shutil
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--mode', choices=['light', 'dark'], help='Preview a palette in isolated settings.')
args = parser.parse_args()
output = root/'preview'/f'lockscreen{"-" + args.mode if args.mode else ""}.png'
if output.exists():
    output.unlink()
with tempfile.TemporaryDirectory(prefix='sequoia-lockscreen-') as staging:
    subprocess.run(['python3', str(root/'tools/install-lockscreen.py'), '--prefix', staging], check=True)
    shell = Path(staging)/'plasma/shells/org.kde.plasma.desktop'
    qml = shell/'contents/lockscreen'
    # These fixtures are confined to the temporary preview, never installed.
    (qml/'MediaControls.qml').write_text(('''import QtQuick
SequoiaMediaCard {
    trackTitle: "Golden Hour"
    artist: "Sequoia Eleven · Media preview"
    playerName: "Music"
    playing: true
    artwork: "ARTWORK"
}
''').replace('ARTWORK', (root/'preview/media-art.svg').as_uri()))
    p=qml/'LockScreenUi.qml';s=p.read_text().replace('    id: lockScreenUi','''    id: lockScreenUi
    Timer { interval: 300; running: true; onTriggered: lockScreenRoot.uiVisible = true }
''',1);p.write_text(s)
    p=qml/'LockScreen.qml';s=p.read_text().replace('    id: root',f'''    id: root
    Timer {{
        interval: 2500; running: true
        onTriggered: root.grabToImage(function(result) {{
            if (!result.saveToFile("{output}")) console.error("CAPTURE_FAILED");
            else console.log("SEQUOIA_CAPTURE_OK");
        }})
    }}
''',1);p.write_text(s)
    env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',QT_QUICK_BACKEND='software')
    if args.mode:
        # Exercise real palette selection without changing the user's session.
        config = Path(staging)/'config'
        config.mkdir()
        current = Path(os.environ.get('XDG_CONFIG_HOME') or Path.home()/'.config')
        for name in ['kscreenlockerrc', 'plasmarc']:
            if (current/name).exists(): shutil.copy2(current/name, config/name)
        palette = configparser.ConfigParser(interpolation=None, strict=False)
        palette.optionxform = str
        palette.read([current/'kdeglobals', root/'color-schemes'/f'SequoiaEleven{args.mode.title()}.colors'])
        with (config/'kdeglobals').open('w') as stream: palette.write(stream, space_around_delimiters=False)
        subprocess.run(['kwriteconfig6', '--file', str(config/'plasmarc'), '--group', 'Theme',
                        '--key', 'name', f'sequoia-eleven-{args.mode}'], check=True)
        env['XDG_CONFIG_HOME'] = str(config)
    process=subprocess.Popen(['/usr/libexec/kscreenlocker_greet','--testing','--shell',str(shell)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    try:
        log,_=process.communicate(timeout=5)
    except subprocess.TimeoutExpired:
        process.terminate();log,_=process.communicate(timeout=5)
    journal = subprocess.run(['journalctl','--user','--no-pager','-o','cat',f'_PID={process.pid}'],capture_output=True,text=True).stdout
    log += journal
    errors = [line for line in log.splitlines() if any(term in line for term in ('ReferenceError:', 'TypeError:', 'unavailable', 'Cannot assign', 'Failed to load lockscreen'))]
    print('\n'.join(errors) if errors else 'Greeter loaded without QML errors.')
    assert output.exists() and output.stat().st_size > 1000 and not errors, 'Lock-screen preview failed'
    print('Saved',output)

#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
source_dir="$project_dir/application-style/SequoiaEleven"
build_dir="$project_dir/build/desktop"

# CMake caches absolute source/build paths. A copied checkout must configure
# from scratch, even when it includes another account's successful build.
if [[ -f "$build_dir/CMakeCache.txt" ]]; then
    cached_source=$(sed -n 's/^CMAKE_HOME_DIRECTORY:INTERNAL=//p' "$build_dir/CMakeCache.txt")
    cached_build=$(sed -n 's/^CMAKE_CACHEFILE_DIR:INTERNAL=//p' "$build_dir/CMakeCache.txt")
    if [[ "$cached_source" != "$source_dir" || "$cached_build" != "$build_dir" ]]; then
        saved_dir=$(mktemp -d "$project_dir/build/desktop-relocated-XXXXXXXX")
        mv -- "$build_dir" "$saved_dir/desktop"
        printf 'Checkout moved; saved the old CMake build in %s and configuring a fresh build.\n' "$saved_dir/desktop"
    fi
fi

cmake -S "$source_dir" -B "$build_dir" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release -DBUILD_QT5=OFF -DBUILD_QT6=ON -DBUILD_TESTING=OFF \
    -DCMAKE_INSTALL_PREFIX=/usr -DKDE_INSTALL_LIBDIR=lib64 \
    -DKDE_INSTALL_QTPLUGINDIR=lib64/qt6/plugins
cmake --build "$build_dir" --parallel "${BUILD_JOBS:-4}"
DESTDIR="$project_dir/.staging/desktop" cmake --install "$build_dir"

#!/usr/bin/env python3
"""Capture the installed Plasma Login greeter with staged appearance and mock authentication."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--mode', choices=('light', 'dark'), default='light')
args = parser.parse_args()
output = ROOT/'preview'/f'login-{args.mode}.png'
output.unlink(missing_ok=True)
with tempfile.TemporaryDirectory(prefix='sequoia-login-preview-') as temporary:
    staging = Path(temporary)
    subprocess.run(['python3', str(ROOT/'tools/install-login.py'), '--prefix', str(staging/'system'),
                    '--mode', args.mode], check=True)
    # Only the preview copy gets a capture timer and a background. In production,
    # Plasma Login runs its wallpaper plugin in a separate process/layer.
    module = staging/'qml/org/kde/breeze/components'
    shutil.copytree('/usr/lib64/qt6/qml/org/kde/breeze/components', module)
    qmldir = module/'qmldir'
    qmldir.write_text('\n'.join(line for line in qmldir.read_text().splitlines()
                                if not line.startswith('prefer '))+'\n')
    clock = module/'Clock.qml'
    source = clock.read_text().replace('import QtQuick\n',
        'import QtQuick\nimport QtQuick.Window\nimport org.kde.plasma.login as PlasmaLogin\n')
    wallpaper = ROOT/'wallpapers/SequoiaEleven/contents'/('images_dark' if args.mode == 'dark' else 'images')/'3840x2160.png'
    source = source.replace('    id: root', f'''    id: root
    Image {{
        parent: root.parent.parent
        anchors.fill: parent
        z: -100
        source: "{wallpaper.as_uri()}"
        fillMode: Image.PreserveAspectCrop
        Rectangle {{ anchors.fill: parent; color: "#20000000" }}
    }}
    Timer {{
        interval: 100; running: true
        onTriggered: {{
            root.Window.window.width = 1280;
            root.Window.window.height = 800;
            PlasmaLogin.GreeterState.activateWindow(root.Window.window);
        }}
    }}
    Timer {{
        interval: 2200; running: true
        onTriggered: root.parent.parent.grabToImage(function(result) {{
            if (result.saveToFile("{output}")) console.log("SEQUOIA_LOGIN_CAPTURE_OK");
            else console.error("CAPTURE_FAILED");
            Qt.quit();
        }})
    }}''', 1)
    clock.write_text(source)
    env = os.environ.copy()
    env.update(QT_QPA_PLATFORM='offscreen', QT_QUICK_BACKEND='software', QT_LOGGING_TO_CONSOLE='1',
               QT_QPA_PLATFORMTHEME='kde', QML_IMPORT_PATH=str(staging/'qml'),
               XDG_CONFIG_HOME=str(staging/'system/var/lib/plasmalogin/.config'),
               XDG_DATA_DIRS=str(staging/'system/usr/local/share')+':/usr/local/share:/usr/share',
               XDG_CACHE_HOME=str(staging/'cache'))
    process = subprocess.Popen(['/usr/libexec/plasma-login-greeter', '--test'], env=env,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        log, _ = process.communicate(timeout=12)
    except subprocess.TimeoutExpired:
        process.terminate()
        log, _ = process.communicate(timeout=5)
    journal = subprocess.run(['journalctl', '--user', '--no-pager', '-o', 'cat', f'_PID={process.pid}'],
                             capture_output=True, text=True).stdout
    log += journal
    (ROOT/'preview'/f'login-{args.mode}.log').write_text(log)
    errors = [line for line in log.splitlines() if any(term in line for term in
              ('ReferenceError:', 'TypeError:', 'Cannot assign', 'is not installed', 'unavailable', 'CAPTURE_FAILED'))]
    assert not errors, '\n'.join(errors)
    assert output.exists() and output.stat().st_size > 1000, log
    print('Real Plasma Login greeter loaded without QML errors. Saved', output)

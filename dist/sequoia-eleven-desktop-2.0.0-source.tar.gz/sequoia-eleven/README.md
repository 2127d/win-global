# Sequoia Eleven

A coordinated Plasma desktop inspired by macOS Sequoia and Windows 11: neutral
materials, soft corners, compact controls, and clear blue application selections.
Available in Light and Dark, with a matching wallpaper that follows the system
color scheme. Includes Sequoia Tahoe icons with bold, smooth action glyphs;
your panel layout is preserved.

Both appearances now include **Solid** and **Transparent** application finishes,
with matching native window decorations. Choose **Sequoia Eleven Light Solid**,
**Light Transparent**, **Dark Solid**, or **Dark Transparent** in System Settings
→ Colors & Themes → Global Theme to select a coordinated set. The color schemes
also appear under Colors; **Sequoia Eleven Solid** and **Sequoia Eleven Transparent**
appear under Window Decorations and follow the selected light/dark palette.

Every color scheme sets **Frames and Outlines** to **0%**. View backgrounds match
the window's RGB colors, with independent opacity. Transparent uses a frosted
application canvas and titlebar (72% tint), with **solid floating toolbars,
sidebars, content views, and cards**. Rounded corners, inset spacing, and soft
shadows separate these islands from the glass around them. Text, icons,
selections, and button faces keep their normal opacity. The compiled Qt style
enables compositor blur; the Quick extension supplies matching opaque islands
over transparent pages in supported KDE apps. The glass canvas uses the same
tint as the native titlebar for a continuous finish. Solid uses opaque application
surfaces and titlebars.
Plasma panels and desktop widgets retain their existing finishes.

![Sequoia Eleven desktop surfaces](preview/dark.png)
![Sequoia Eleven application style](preview/applications-dark.png)
![Sequoia Eleven Qt Quick application surfaces](preview/systemmonitor-islands-dark.png)
![Sequoia Eleven lock screen](preview/lockscreen.png)

## What is included

- **Sequoia Tahoe icons:** bundled MacTahoe application and folder artwork with
  heavier monochrome action, toolbar, and tray glyphs. Light and dark variants
  follow the selected global theme. Original Tahoe installations remain available.
- **Plasma style:** charcoal or porcelain panels, translucent widget and OSD
  backgrounds, corrected rounded shadows, compact task highlights, and subtle
  gray/white active panel-widget highlights. Desktop widgets with standard
  backgrounds use Plasma's wallpaper blur, clipped to their rounded corners.
  Panel blur masks sit one pixel inside the rounded border to contain edge spill.
  Frosted light widgets use a white tint and fine bright rim; dark widgets use
  charcoal glass with a softer rim, preserving diffuse wallpaper color beneath.
- **Color schemes:** coordinated window, view, toolbar, selection, disabled,
  inactive, and complementary colors for both appearances.
- **Application style:** a separate, compiled Qt 6 fork of the Darkly source from
  your home folder. Tahoe-inspired floating toolbar and sidebar islands, inset
  content views, 14px surface corners, and soft shadows in both
  appearances. Rounded controls, slim scrollbars, segmented tabs, translucent
  menus, and restrained animation complete the style.
  Native KDE settings sidebars reserve enough width for their labels and inset
  selection highlights, including Konsole's profile settings.
- **Qt Quick/Kirigami extension:** matching floating drawers, page headers,
  framed scroll views, and rounded cards for System Monitor, System Settings,
  and Discover, activated through reversible user-local application launchers.
- **Window decoration:** a separate native KWin plugin with rounded corners,
  centered titles, compact title bars, and red/yellow/green controls. Inactive
  controls become neutral; hovering reveals their symbols without enlarging them.
- **Typography:** bundled Adwaita Sans (Inter-based) for clear desktop, menu,
  toolbar, and window-title text. Regular 10pt UI text, medium 10pt titles, and
  conservative smoothing; Nunito remains available for the clock and splash.
- **Lock screen:** a large, quiet clock, prominent avatar, compact translucent password
  field with a smooth white border, compact unlock button without hover scaling, steady action buttons, a gently shaded wallpaper,
  and a compact album-art media card with accessible playback controls that follows
  the active light/dark color scheme.
- **Global Themes:** Light and Dark entries in System Settings and a matching
  startup splash. The lock-screen override is shared by both appearances.
- **Login screen:** a system-wide Plasma Login Manager installer shares the
  Sequoia Eleven colors, Plasma controls, Adwaita Sans font, and adaptive wallpaper.
  A settings watcher follows the selected desktop account's light/dark variant.
- **Adaptive wallpaper:** the preview's blue gradient and rounded lavender,
  rose, and peach bands in coordinated light and dark palettes. One native KDE
  wallpaper package includes both 3840×2160 images and editable SVG sources.

## Build and install the complete desktop

Tested on Fedora 44, Plasma 6.7.5, Qt 6.11.2, and KDE Frameworks 6.30.

Install build dependencies on Fedora:

```sh
sudo dnf install cmake gcc-c++ ninja-build extra-cmake-modules \
  qt6-qtbase-devel qt6-qtdeclarative-devel kdecoration-devel \
  kf6-frameworkintegration-devel kf6-kcmutils-devel kf6-kirigami-devel \
  kf6-kguiaddons-devel kf6-ki18n-devel kf6-kwindowsystem-devel
```

Build, install the independently named plugins, and apply the desktop:

```sh
python3 tools/build.py
bash tools/build-desktop.sh
sudo cmake --install build/desktop
python3 tools/apply-desktop.py --mode dark --material solid
```

Run the build and per-user installers as the account that will use the theme;
only `sudo cmake --install build/desktop` needs administrator access. Paths are
derived from the checkout and the current account. If you copy the project to
another account or folder, `tools/build-desktop.sh` detects the old CMake paths,
preserves the stale build under `build/desktop-relocated-*`, and rebuilds at the
new location. Do not run `cmake --install` on a copied build before rebuilding.
You can omit `build/` and `.staging/` when copying the project; the source archive
already excludes those generated directories. Each account must run the per-user
installer to get its own theme files and settings.

Per-user installers honor `XDG_DATA_HOME` and `XDG_CONFIG_HOME`; unset or empty
values use the normal directories under the current home. Snapshots can also be
restored when these directories are outside the home folder. Keep the same XDG
settings when restoring. Account-path test coverage and its limits are recorded
in [VALIDATION.md](VALIDATION.md).

Use `--mode light` for the light appearance. The application and decoration plugin
names are `SequoiaEleven` and `org.kde.sequoiaeleven`; the original Darkly source,
plugins, and settings are untouched. The fork's settings live in `sequoiaelevenrc`.
Restart open applications to load the new application style. The lock-screen
changes appear the next time the screen locks; the splash appears at login.
Use `--material transparent` for the frosted variant, or `--material legacy` for
the original customizable appearance. The build installs both new decoration
plugins alongside the original `org.kde.sequoiaeleven` plugin. To add the new
choices to an existing installation without selecting a theme, rebuild/install
the compiled plugins, run `./install.sh`, and refresh the Quick extension with
`python3 tools/install-quick-islands.py`.
The full installer selects the adaptive wallpaper on the desktops. Use
`--keep-wallpaper` to install it while retaining your current background.

The full installer installs Adwaita Sans for UI text and Nunito for the clock
and splash. Both theme variants use the same UI font sizes; fixed-width
terminal/editor fonts are preserved. Both families are bundled unmodified with
SIL Open Font Licenses and SHA-256 manifests, so installation needs no download.
To install just the font files, run `python3 tools/install-fonts.py`.

To apply the UI fonts and smoother rendering to an existing desktop, run
`python3 tools/apply-fonts.py`. It snapshots the affected files, selects Adwaita
Sans for KDE and GTK UI text, and sets grayscale antialiasing with slight hinting.
It preserves font size, DPI, panel geometry, and menu spacing. The script prints
a restore command; reopen applications to refresh their text rendering. Compare
actual Qt-rendered text in [the font preview](preview/fonts.png).

The apply script saves a timestamped snapshot under
`~/.local/share/sequoia-eleven/backups/` before changing settings or installed
artwork. It prints the exact restore command:

```sh
python3 tools/restore-desktop.py /path/to/the/backup
```

Restore returns the saved settings and local artwork. The independently named
compiled plugins remain installed but unused. Log out and back in after restoring.

## Artwork-only installation

`./install.sh` installs the Plasma styles, all Global Theme/color variants,
Sequoia Tahoe icons, and wallpaper.
It does not activate anything or install compiled plugins. Select the desired
Plasma Style and Colors in System Settings. `--prefix /path/to/data` stages them.
Select **Sequoia Eleven** in Wallpaper settings, with dynamic switching set to
follow the color scheme. Select the wallpaper package rather than an individual
PNG so Plasma can choose its light or dark image automatically. Both Global
Themes also name this package as their default wallpaper.
The archives in `dist/sequoia-eleven-{light,dark}-2.0.0.tar.gz` contain these styles.
The standalone wallpaper is in `dist/sequoia-eleven-wallpaper-2.0.0.tar.gz`.
The standalone icon family is in `dist/sequoia-tahoe-icons-2.0.0.tar.gz`;
install all three SequoiaTahoe directories together under `~/.local/share/icons`.
The desktop source archive contains the complete source and installation tools.

| Light wallpaper | Dark wallpaper |
| --- | --- |
| ![Light wallpaper](preview/wallpaper-light.png) | ![Dark wallpaper](preview/wallpaper-dark.png) |

## Floating Qt Quick applications

Qt Quick apps use a separate component layer from the compiled Qt Widgets style.
After installing the application style, install this extension with:

```sh
python3 tools/install-quick-islands.py
```

This requires the system's PySide6 package (`python3-pyside6` on Fedora). It copies
the installed KDE QML components, applies the surface changes, and uses the system
plugin libraries. It creates user-local launchers for installed copies of System
Monitor, System Settings, Info Center, and Discover. Fully quit and reopen those apps from the
application menu. No C++ style rebuild or logout is needed for this extension.
Use `--apps systemmonitor` to select only that app on a first installation.

The extension lives under `~/.local/share/sequoia-eleven/quick-islands/`. It leaves
system QML files and the Plasma shell unchanged. Other compatible native Qt Quick
apps can be launched explicitly through its wrapper:

```sh
~/.local/share/sequoia-eleven/quick-islands/sequoia-quick APPLICATION
```

Application-defined backgrounds and layout overrides may still need individual
adjustments; GTK, Electron, and isolated Flatpak apps are outside this extension.
Transparent schemes provide real canvas alpha and request compositor blur,
while drawers, headers, framed views, and cards remain opaque. Solid schemes
keep the same geometry with opaque canvases too. Restart applications
after changing material so their window buffers and palettes are recreated.
System Settings and Info Center use Discover's solid, rounded sidebar treatment:
one inset island spans the search header and navigation, including category
transitions. Navigation retains inset spacing and selection highlights. Forms
and unframed list/grid pages share their native host's glass canvas; explicitly
framed content views remain solid. The sidebar treatment follows the shared
component, independent of the application's name.
Merkuro Calendar (RPM) also uses a continuous floating sidebar, inset month/week/
schedule/task surfaces, and an aligned menu/header. Its installed QML is extracted
into the version-checked overlay; a small launcher-scoped Qt URL interceptor
loads that copy while the RPM executable and calendar services remain native.
The installer builds this helper when Merkuro is installed (requires a C++
compiler and Qt 6 Core/QML development files). Refresh after Merkuro updates;
the launcher falls back to the standard application when source versions change.
The collapsed sidebar reserves room for the island padding so navigation icons
remain fully visible.
The background outside the Settings/Info Center floating sidebar uses the window
palette's tint and transparency (`#F2F3F5` at 72% in light Transparent mode), so
compositor blur remains visible around the solid panel. Solid mode stays opaque.
Inset scrolling views clip their contents at the padded viewport, keeping
partially visible rows and highlights inside the floating panel's edges.
Native dialogs, tool windows, and Quick windows request blur when their surfaces
are created or reopened, including Quick windows without native-styled controls.
Applications that paint their own opaque backgrounds may cover the glass;
GTK, Electron, and isolated Flatpak runtimes require their own style support.

Rerun the installer after KDE upgrades. The launcher checks the source components
and falls back to the standard components when they change, until refreshed.
Reinstalling preserves the original launcher backups. To remove the extension
and restore those launchers:

```sh
python3 tools/install-quick-islands.py --remove
```

## Lock screen and local widget adjustments

### Optional dock and menu-bar refinement

`python3 tools/apply-mac-panels.py` refines an existing bottom icons-only dock
and top global-menu panel. It saves both panel configuration files under
`$XDG_DATA_HOME/sequoia-eleven/backups/before-mac-panels-*` (normally under
`~/.local/share`), preserves pinned applications, sets a 68px
floating dock with more icon spacing, and adds a separator, Downloads and the
native Trash widget. The top bar becomes 32px, with a bold application name,
regular 10pt clock text, fewer spacers, and secondary tray controls available
inside Control Center. Standalone Color Picker and Recent Files widgets remain.
Use `--dry-run` to inspect the Plasma script without installing or applying it.

The Control Center installer also supplies the native task-manager overlay:
10% hover zoom and small running-app dots on horizontal icons-only tasks.
Native launch, grouping, drag, context menus, badges and tooltips are retained;
animation timing follows Plasma settings. Install with
`python3 tools/install-control-center.py`, apply the panel script, then run
`systemctl --user restart plasma-plasmashell.service` to load the overlay.
The task-manager plugin joins the version fingerprint checks. Never overwrite
the running shell's helper library in place; use the installer, which replaces
the installation directory. `python3 tools/verify-dock.py` checks the staged
overlay in a private Wayland/D-Bus session.

Downloads is a compact fan popup: up to ten newest files or folders, with
40px theme icons on the right and horizontal, crisp filename labels on the left.
The curved, tilted stack has a transparent, unblurred backdrop, and “See more in File
Manager” sits above the files. Rows unfold from the folder with staggered motion,
then travel and shrink back into it before the popup hides or opens a file.
It follows live folder
changes, hides dotfiles, supports arrow keys/Enter/Space/Escape, and reduces its
entry count on short displays. Install it on an already configured dock with
`python3 tools/install-downloads-stack.py`; only the matching Downloads shortcut
is replaced. Build the style first with `tools/build-desktop.sh`; the installer
also installs a user-local style and a Plasma service override for the blur opt-out.
Restart Plasma to load updates. It saves backups under
`$XDG_DATA_HOME/sequoia-eleven/backups/before-downloads-fan-*` (normally under
`~/.local/share`).
`tools/verify-downloads-stack.py` checks temporary files without opening them;
`tools/verify-downloads-native.py` checks the real Plasma popup.

The native dock Trash uses the icon pack's regular empty/full bin artwork,
following the selected light or dark icon theme. This is included in the
Control Center/dock overlay installed by `tools/install-control-center.py`.

The same overlay polishes notification banners and history with clearer text,
quieter app headers, inset controls, rounded action buttons and consistent card
spacing in both themes. Native replies, progress, timeouts and Do Not Disturb
remain available. `python3 tools/verify-notifications.py` verifies the native
flow in an isolated session; `--dark --large --rtl` covers alternate layouts.

The system tray can open a **Control Center** with direct Wi-Fi, Bluetooth,
Do Not Disturb, microphone mute, speaker volume, per-display brightness, and media
controls. Rounded cards follow the desktop palette, including the remaining tray
widgets directly in the dashboard. Detail menus share inset rounded toolbars,
soft content panels, card rows and pill tabs while retaining KDE's native device
lists and actions. The footer includes settings, lock, and the standard session/power prompt.

```sh
python3 tools/install-control-center.py
systemctl --user restart plasma-plasmashell.service
```

This changes the existing tray's overflow button into a sliders button. It preserves
panel layout and application status icons. The source is in
[`plasma/control-center`](plasma/control-center); installation lives under
`~/.local/share/sequoia-eleven/control-center`. A user service override starts
Plasma through a version-checking launcher and a small applet QML entry-point
helper, because this Plasma release embeds its tray QML in a library. System
libraries and the lock-screen shell override remain unchanged. Child applications
do not inherit the helper. After a Plasma upgrade, the launcher uses the original
tray until the installer is rerun.

Unavailable hardware is shown as unavailable. Brightness requires a display
exposed by PowerDevil; the widget does not simulate brightness with an overlay.
Wi-Fi and Bluetooth switches act immediately. Power opens Plasma's confirmation
screen. For previews and verification, see [Control Center validation](plasma/control-center/README.md).

To restore the original tray:

```sh
python3 tools/install-control-center.py --remove
systemctl --user restart plasma-plasmashell.service
```

`python3 tools/install-lockscreen.py` generates a user-local desktop shell from
this machine's current system shell and overlays the visual changes. It preserves
Plasma's authentication, failure handling, password synchronization, virtual
keyboard, and session actions. It refuses to overwrite an unrelated custom shell.
**Run it again after Plasma upgrades** to refresh the copied system files.
The generated directory is `~/.local/share/plasma/shells/org.kde.plasma.desktop`,
identified by `.sequoia-eleven-lockscreen`. Removing it returns to the system shell.

## Login screen

This machine uses **Plasma Login Manager**, whose appearance is configured under
its own system account. After installing the compiled desktop style, apply the
matching login appearance with:

```sh
sudo python3 tools/install-login.py --install --user "$USER"
```

If your desktop uses a custom `XDG_CONFIG_HOME`, also pass
`--config-dir "$XDG_CONFIG_HOME"` to that command; sudo normally clears this
environment variable. Without sudo, staging detects the current account's XDG
configuration directory automatically.

The installer puts both appearances, the wallpaper, and fonts in
`/usr/local/share`, selects the wallpaper in `/etc/plasmalogin.conf`, and applies
the current appearance to the `plasmalogin` account. It preserves existing
authentication, autologin, and session settings. The native greeter provides
its clock, avatar, password entry, session selector, and power actions.
Its layout remains the upstream Plasma Login layout; the lock-screen QML
override is a separate feature.

`sequoia-eleven-login-sync.path` follows changes to the selected user's
`kdeglobals` and `kdedefaults/kdeglobals`, including Global Theme switching.
The service accepts only the two Sequoia Eleven variants and uses root-owned
theme assets; it drops to the greeter account before writing appearance settings.
Other desktop themes leave the last Sequoia login appearance in place. The
login screen is shared by all users and follows the account chosen at install
time. Changes appear when the greeter next starts; installation does not restart
the display manager or interrupt the desktop session.

Every overwritten file is backed up under `/var/backups/sequoia-eleven-login/`.
The installer prints a restore command, for example:

```sh
sudo python3 tools/install-login.py --restore /var/backups/sequoia-eleven-login/TIMESTAMP
```

Stage without administrator access with
`python3 tools/install-login.py --prefix .staging/login --mode light` (use a fresh
directory). Validate with `python3 tools/verify-login.py`. The preview uses the
installed greeter's mock authentication mode, with a temporary screenshot hook
and a wallpaper backdrop standing in for the separate wallpaper process:

```sh
python3 tools/preview-login.py --mode light
python3 tools/preview-login.py --mode dark
```

| Light login | Dark login |
| --- | --- |
| ![Light login](preview/login-light.png) | ![Dark login](preview/login-dark.png) |

These software-rendered previews show the upstream fallback avatar and text
rendering. The greeter's normal GPU rendering supplies its avatar mask and
shadows. Appearance integration follows KDE's
[Plasma Login configuration and settings synchronization](https://github.com/KDE/plasma-login-manager/tree/Plasma/6.7/src/frontend/kcm).

## Local widget adjustments

For the separately installed Game Drawer widget,
`python3 tools/install-gamedrawer.py` insets its panel button background by 6px
without changing its icon or clickable area. It saves the original QML alongside
it as `main.qml.before-compact-highlight`. Reload the widget to see changes.

## Development and previews

Edit `tools/build.py` for Plasma geometry, palettes, color schemes, and Global
Theme packaging. Application and decoration sources are in
`application-style/SequoiaEleven/`. Original lock-screen components are in
`lockscreen/`; the installer applies compatible changes to the system's remaining
QML components. No authentication implementation is replaced.
`tools/wallpaper.py` preserves the original preview backdrop's geometry and
palettes, generates editable SVGs, and renders the 4K PNGs with PySide6/QtSvg.
Run it independently to rebuild just the wallpaper, or use `tools/build.py`
to rebuild all artwork and archives. Artwork builds require PySide6
(`python3-pyside6` on Fedora); installing the prebuilt artwork does not.

```sh
python3 tools/build.py
python3 tools/preview.py --dark --output preview/dark.png
python3 tools/preview.py --output preview/light.png
python3 tools/preview-widget-glass.py
python3 tools/preview-applications.py --dark
python3 tools/preview-applications.py
python3 tools/verify-application-islands.py
python3 tools/verify-quick-islands.py
python3 tools/preview-quick-islands.py
python3 tools/preview-quick-islands.py --dark
python3 tools/preview-decoration.py --dark
python3 tools/preview-decoration.py
python3 tools/preview-lockscreen.py
python3 tools/preview-lockscreen.py --mode light
python3 tools/preview-lockscreen.py --mode dark
python3 tools/verify-media.py
```

Previews use actual KSvg assets, the compiled Qt style, the compiled KWin decoration,
and the real greeter in offscreen testing mode. The lock-screen preview injects
sample media only into a temporary copy. The media test runs on an isolated D-Bus
session and never controls your real players. Native compositor blur is not shown
in software-rendered previews. The decoration preview engine uses its own sample
button arrangement; activation places close/minimize/maximize on the left.

The compiled application plugin styles native Qt 6 widgets; the optional Quick
extension covers the shared QML components described above. Qt 5, GTK, browser content,
Electron apps, and sandboxed Flatpaks may use their own styles and icons.
The full installer selects Sequoia Tahoe icons and applies the bundled
wallpaper unless `--keep-wallpaper` is supplied. See `VALIDATION.md` for verified behavior.

Qt Widgets islands apply to standard Qt toolbars, dock panels, framed scroll
views, and KDE-marked navigation lists. Their 5px outer insets and reserved content
padding keep controls clear of the rounded edges. Applications that draw their
own surfaces can retain their own layouts. The surface tint and
shadow suggest glass; actual backdrop blur depends on the application and KWin.
To update an already installed theme, run `bash tools/build-desktop.sh`, then
`sudo cmake --install build/desktop`, and restart applications.

## License

Sequoia Tahoe is derived from Vince Liuice's MacTahoe icon theme under **GPL-3.0**.
Each bundled icon variant retains `AUTHORS`, `COPYING`, and a modification notice.
`tools/build-tahoe-icons.py` reproduces the changes from an installed MacTahoe-blue
family. The before/after sheet is `preview/tahoe-icons.png`.

Original Sequoia Eleven artwork, QML, and tools: MIT. The copied Darkly application
style and decoration are **GPL-2.0-or-later**; their notices, upstream README,
AUTHORS, and COPYING are retained. Generated lock-screen files derived from KDE
retain their original GPL/LGPL notices. Generated Quick component overrides also
retain their upstream KDE license notices; the original Quick island and tools are MIT. Adwaita Sans and Nunito are distributed unmodified under
the **SIL Open Font License 1.1**; see `fonts/AdwaitaSans/LICENSE`, `fonts/Nunito/OFL.txt`, and the
[Nunito project](https://github.com/googlefonts/nunito). This project is not affiliated with Apple,
Microsoft, or KDE.


### Custom panel widget collection

The Icons-only Task Manager now has floating settings cards and an Animations
page with a live preview, enable switch, zoom/lift styles, intensity, speed,
launch bounce, press feedback, attention pulse and reorder controls. Open the
widget's Configure dialog; Apply stores the settings per widget.

`python3 tools/export-widgets.py` exports the customized System Tray, Icons-only
Task Manager, Downloads and Dock Separator to `~/sandbox/widgets` as **four
`.tar.gz` archives and one `install-widgets.py` script**. The modified system
widgets are independent forks with their own IDs. The tray archive includes
its styled child widgets and unified Notifications.

On the destination account, run:

```sh
cd ~/sandbox/widgets
python3 install-widgets.py
```

The script finds archives in the current folder, installs their packages and
native adapters system-wide using sudo, selects the notification fork for your
account, and restarts Plasma. Existing tray and task-manager instances retain
their settings and pinned apps; add the forks manually through Add Widgets.
The editable source stays in this workspace. Archives containing native adapters
are checked against the target Qt/KDE installation before any files change.
See [widget installation and portability](plasma/WIDGETS.md) for details.

/*************************************************************************
 * Copyright (C) 2014 by Hugo Pereira Da Costa <hugo.pereira@free.fr>    *
 *                                                                       *
 * This program is free software; you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation; either version 2 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * You should have received a copy of the GNU General Public License     *
 * along with this program; if not, write to the                         *
 * Free Software Foundation, Inc.,                                       *
 * 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA .        *
 *************************************************************************/

#include "sequoiaelevenpropertynames.h"

namespace SequoiaEleven
{

const char PropertyNames::noAnimations[] = "_kde_no_animations";
const char PropertyNames::noWindowGrab[] = "_kde_no_window_grab";
const char PropertyNames::netWMForceShadow[] = "_KDE_NET_WM_FORCE_SHADOW";
const char PropertyNames::netWMSkipShadow[] = "_KDE_NET_WM_SKIP_SHADOW";
const char PropertyNames::sidePanelView[] = "_kde_side_panel_view";
const char PropertyNames::toolButtonAlignment[] = "_kde_toolButton_alignment";
const char PropertyNames::menuTitle[] = "_sequoiaeleven_toolButton_menutitle";
const char PropertyNames::alteredBackground[] = "_sequoiaeleven_altered_background";
const char PropertyNames::forceFrame[] = "_breeze_force_frame";
const char PropertyNames::bordersSides[] = "_breeze_borders_sides";
const char PropertyNames::noSeparator[] = "_sequoiaeleven_no_separator";
}

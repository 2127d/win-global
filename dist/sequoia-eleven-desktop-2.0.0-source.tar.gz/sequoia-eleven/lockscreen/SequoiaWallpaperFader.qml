// SPDX-License-Identifier: MIT
import QtQuick
import Qt5Compat.GraphicalEffects

Item {
    id: fader
    property Item clock
    property Item mainStack
    property Item footer
    property alias source: blur.source
    property bool alwaysShowClock: true
    property real factor: state === "on" ? 1 : 0
    state: "on"
    Behavior on factor { NumberAnimation { duration: 350; easing.type: Easing.InOutQuad } }
    FastBlur {
        id: blur
        anchors.fill: parent
        radius: fader.factor * 32
    }
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0; color: Qt.rgba(0.04, 0.05, 0.07, 0.10 + fader.factor * 0.12) }
            GradientStop { position: 0.65; color: Qt.rgba(0.04, 0.05, 0.07, 0.12 + fader.factor * 0.26) }
            GradientStop { position: 1; color: Qt.rgba(0.04, 0.05, 0.07, 0.2 + fader.factor * 0.25) }
        }
    }
    states: [
        State {
            name: "on"
            PropertyChanges { target: fader.mainStack; opacity: 1 }
            PropertyChanges { target: fader.footer; opacity: 1 }
            PropertyChanges { target: fader.clock; opacity: 1 }
        },
        State {
            name: "off"
            PropertyChanges { target: fader.mainStack; opacity: 0 }
            PropertyChanges { target: fader.footer; opacity: 0 }
            PropertyChanges { target: fader.clock; opacity: fader.alwaysShowClock ? 1 : 0 }
        }
    ]
    transitions: Transition {
        NumberAnimation { properties: "opacity"; duration: 250; easing.type: Easing.InOutQuad }
    }
}

// SPDX-License-Identifier: MIT
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.clock as PlasmaClock

ColumnLayout {
    spacing: 2
    Text {
        Layout.alignment: Qt.AlignHCenter
        text: Qt.formatDate(timeSource.dateTime, "dddd, MMMM d")
        color: "#f4f5f7"
        font.family: "Nunito"
        font.pixelSize: 20
        font.weight: Font.Medium
    }
    Text {
        Layout.alignment: Qt.AlignHCenter
        text: Qt.formatTime(timeSource.dateTime, Qt.locale(), Locale.ShortFormat)
        color: "#f9fafc"
        font.family: "Nunito"
        font.pixelSize: Math.min(112, Math.max(64, Screen.height * 0.12))
        font.weight: Font.Medium
        font.letterSpacing: -4
    }
    PlasmaClock.Clock { id: timeSource; trackSeconds: false }
}

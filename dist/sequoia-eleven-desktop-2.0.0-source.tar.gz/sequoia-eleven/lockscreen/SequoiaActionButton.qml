// SPDX-License-Identifier: MIT
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.components as PC
import org.kde.kirigami as Kirigami

PC.Button {
    id: control
    Kirigami.Theme.colorSet: Kirigami.Theme.Complementary
    Kirigami.Theme.textColor: "#f2f3f5"
    hoverEnabled: false
    implicitHeight: 38
    implicitWidth: contentItem.implicitWidth + 28
    leftPadding: 14
    rightPadding: 14
    topPadding: 8
    bottomPadding: 8
    spacing: 7
    font.pixelSize: 12
    background: Rectangle {
        radius: 12
        color: control.down ? "#35ffffff" : "#15ffffff"
        border.width: 1
        border.color: control.visualFocus ? "#a6c5ff" : "#20ffffff"
    }
    contentItem: RowLayout {
        spacing: control.spacing
        Kirigami.Icon {
            source: control.icon.name
            implicitWidth: 16
            implicitHeight: 16
            active: false
            selected: false
            color: "#f2f3f5"
        }
        Text {
            text: control.text.replace(/&/g, "")
            font: control.font
            color: "#f2f3f5"
        }
    }
    Keys.onEnterPressed: clicked()
    Keys.onReturnPressed: clicked()
}

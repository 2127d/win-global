# Validation — Sequoia Eleven 2.0

Environment: Fedora 44, Plasma 6.7.5, Qt 6.11.2, KDE Frameworks 6.30.

## Additional account portability checks (2026-09-26)

- `python3 tools/verify-user-portability.py` passes the desktop and font
  installation/restoration workflows with disposable homes, default XDG paths,
  external XDG directories, empty XDG variables, paths containing spaces, and
  an unrelated working directory. Artwork, fonts, lock-screen files, KConfig
  writes, backups and restoration are real; commands that activate the desktop
  are intercepted. Existing settings are restored and newly installed assets
  are removed by restoration.
- These tests reproduced and fixed two issues: empty XDG variables caused some
  Python installers to use the working directory, and restoration rejected
  valid external XDG destinations. A separate boundary check confirms another
  account's paths and whole HOME/XDG roots are rejected before any restore edits.
- `python3 tools/verify-user-portability.py --optional` passes account-path checks
  for panel/Downloads installation and backups, KPackage discovery, the Game
  Drawer patch, and Quick/Control Center removal. Panel responses and service
  commands are simulated; this does not retest live panel layout behavior.
  Panel tools now respect XDG paths and save backups in user data rather than
  the source checkout. Separate desktop-menu checks pass the same three layouts
  with simulated Plasma responses and real backup/config verification.
- `python3 tools/verify-login-portability.py` passes staged login installation
  for two simulated passwd accounts, normal and sudo invocation, and default
  and external configuration paths. `--config-dir` carries a custom desktop
  configuration path through sudo. No system services or user accounts change.
- All Python tools compile. The previously successful native widget and moved
  CMake build tests below were not repeated. The source distribution was refreshed
  with these fixes; the independent widget archives needed no changes.
- These checks exercise account/path portability on the documented Fedora/KDE
  stack. They do not establish compatibility with every distribution, Plasma
  version, permission setup, or a real separate-user login session. Native
  dependencies and the existing-panel requirements of optional panel tools
  still apply. Hardware integration and authentication were not retested.

## Independent widget archives (2026-09-26)

- `tools/build-widget-forks.py` produces four `.tar.gz` archives and one
  installer. Downloads and Separator are QML packages. The animated task
  manager and tray use their own package IDs, QML, configuration schemas and
  normal native applet adapters. Styled tray children and Trash also have
  independent IDs and are bundled in the tray archive (18 packages total).
- `python3 tools/verify-widget-archives.py --functional` passes installation
  into a temporary system prefix, notification selection, preservation of
  stock tray/task-manager IDs and pinned apps, disabled-notification handling,
  incomplete-archive rejection, rollback after a simulated copy failure,
  retirement of shadowing local packages and preservation of unrelated service
  overrides. It does not install files into the running desktop.
- The four top-level forks and the notification fork load with no Sequoia
  shell-wide preload. Native adapter libraries reuse the installed backends.
  Archive installation verifies CPU architecture, Qt version, upstream
  fingerprints and package checksums before modifying files.
- In a private virtual KWin/Wayland session, the animated task manager passes
  hover/reset, animation toggle, styles/intensity, running-dot checks, native
  schema, Apply and all configuration pages. The fork tray passes audio,
  notification and clipboard detail navigation, including clipboard barcode
  navigation and Back.
- The notification fork passes real delivery on a private D-Bus notification
  server, exactly one styled banner, actions, inline reply, close, critical and
  long-text bounds, progress layout, expiry and DND/history. All test settings,
  clipboard data and services are isolated from the user's session.

## Installation portability, legacy export format (2026-09-26)

- `python3 tools/verify-desktop-portability.py` passes real CMake configure,
  build and staged installation after copying and renaming a checkout. Paths
  contain spaces; incremental builds retain their cache, and relocated builds
  preserve the old directory. `bash tools/build-desktop.sh` also succeeds with
  the full desktop sources.
- `python3 tools/verify-widget-bundle.py --bundle dist/sequoia-widgets --native`
  passes checksum verification, source relocation, installation with a temporary
  HOME and XDG directories, both standalone archive installs, same-version
  reinstall, backups and restoration. A missing QML entry point is rejected
  before the existing installation changes. Panel configuration is preserved.
- Both installed applets create visible QML items in offscreen `plasmawindowed`
  with the control-center overlay enabled, on a private D-Bus session with
  service activation disabled. These are isolated directory/session tests on
  this machine, not a retest of the reported guest login or its panel.
- The reported guest widget error was not reproduced. The former installer
  copied packages without checking their entry points; installation now uses
  KPackage and explicitly verifies IDs and QML paths before and after install.
  `tools/install-widgets.py --check` provides installed paths for diagnosis.

## Merkuro Calendar (2026-09-21)

- RPM 26.08.1: local QML override loads with the native executable. Month Light
  Transparent, Week Dark Transparent at 150%, Schedule Light Solid, and Tasks
  Dark Transparent in RTL at 650px height pass navigation and rendering checks.
- Opaque sidebar surfaces, expected window tint (184/255 or 255/255), transparent
  native clear color, and material alpha at multiple outer margins verified.
  Previews inspected; no QML binding/type errors. Software rendering avoids an
  incomplete offscreen OpenGL framebuffer capture after resizing at high DPI;
  the month view was also inspected under real Wayland.
- Preview startup hooks are scoped to the target executable. Calendar previews
  use a distinct AKONADI_INSTANCE, private XDG directories and bus, and stop the
  private instance/process group before cleanup.
- Launcher installation/restoration and stale-source fallback pass. Installed
  wrapper preserves calendar-file URL arguments and enables the Merkuro-only
  interceptor. The current and legacy desktop entries are installed.

## Sequoia Tahoe icons (2026-09-21)

- Qt successfully renders all 14,966 modified SVGs. The bundled theme family
  has no missing or external symlink targets; directory declarations and all
  six global-theme icon selections validate. Upstream GPL-3.0 notices retained.
- Hash comparison confirms 3,721 application, MIME, preference and animation
  assets remain unchanged. Native-size and enlarged light/dark previews reviewed
  in `preview/tahoe-icons.png`, including alert colors and the widened close X.
- `install.sh --prefix /tmp/sequoia-tahoe-install-check` installs all assets and
  successfully generates the three GTK icon caches. Python compilation and
  shell syntax checks pass.
- Live `kiconfinder6` resolves arrow, volume, brightness and copy icons from
  SequoiaTahoe-dark. Plasma was refreshed; the live tray capture confirms heavier
  glyphs. Original MacTahoe theme directories remain available.

## Rounded panel blur containment (2026-09-21)

- `tools/verify-panel-mask.py` checks actual KSvg regions for all eight panel
  assets at bottom-panel, top-panel, and vertical-panel sizes. All 24 masks pass
  at both 100% and 150% scaling: one-pixel inset, rounded corner exclusions,
  and continuous interior coverage. Theme blur stays enabled.
- Generated SVGs are unchanged outside their mask groups: visible surfaces,
  shadows, padding, and opacity are preserved.
- Installed assets match the generated files after Plasma reload; saved panel
  configuration and compositor blur remain unchanged. Live captures are
  `preview/panel-blur-before.png` and `preview/panel-blur-after.png`; the different
  wallpapers limit direct visual comparison.

## Restored translucent sidebar backing (2026-09-21)

- Settings Light Transparent and Info Center Dark Transparent: actual sidebar
  backing color exactly equals the native Window palette, including alpha 184.
  The floating sidebar and header remain opaque; clipping checks pass.
- QWidget::grab repaints the parent underneath the embedded scene, reporting
  alpha 235 in the outer margin. Validation separately checks the actual scene
  backing's alpha rather than treating that composed diagnostic pixel as its
  paint color. This restores the intermediate rendering confirmed by the user.
- Launcher installation/refresh/fallback/restoration checks pass.

## Most-used pages and sidebar base color (2026-09-21)

- Confirmed saved Settings usage history remained present. Selecting the
  existing Default activity restored the live MostUsedModel to six rows;
  its source model reports twelve rows. Live Settings capture visibly shows
  all six shortcuts (`preview/settings-most-used-restored.png`).
- Preview sessions now use private XDG_DATA_HOME and XDG_STATE_HOME. The live
  current activity remains correct after the isolated captures complete.
- Wayland Settings and Info Center Light Transparent captures measure exact
  sidebar outer-margin RGBA (242,243,245,255), matching `#F2F3F5`. Dark Settings
  with 150% scaling, RTL and scrolled navigation measures (37,38,41,255).
- Content retains alpha 184, floating sidebar/header alpha 255, and scrolling
  clips inside its inset viewport. Launcher lifecycle checks pass.

## Sidebar overflow clipping (2026-09-21)

- Real Wayland previews scroll sidebars partway down to expose partial rows.
  Checks require the viewport's clip flag and containment within the ScrollView's
  padded bounds. The capture helper traverses the visual tree to include drawers.
- Passes Settings Dark Transparent, Settings Light Transparent at 150% in RTL,
  Info Center Light Solid, and Discover Dark Transparent at 650px window height.
  Settings capture inspected: partial rows stop above the lower panel edge.
- Sidebar/header opacity and full-height surface checks pass. Discover also
  passes its three-card opacity and 46 highlight containment checks.
- Quick installation, refresh, argument handling, fallback, edit protection,
  and restoration checks pass. Refreshed the installed overlay.

## Settings follows the Discover reference (2026-09-21)

- Supersedes the transparent sidebar below. A single Island spans the shared
  SideBarItem host, including search/back header and category pages. The rendered
  component matches Discover's 5px inset, 14px radius, and opaque surface.
- Real Wayland previews: Settings Light Transparent, Keyboard category Light
  Transparent, Settings Dark Transparent at 150% with RTL layout, Info Center
  Dark Transparent and Light Solid. Inspected Settings and category captures.
- Capture checks require exactly one visible sidebar surface covering the host
  height. Sidebar body, header/body join, and toolbar alpha are 255; transparent
  content alpha remains 184. Solid content alpha remains 255.
- Quick launcher installation, refresh, arguments, fallback, edit protection,
  and restoration checks pass.

## Settings sidebar and content matching (2026-09-21)

- Corrects the earlier opaque sidebar behavior: the shared navigation pages
  now use the content canvas with no added island fill, gradient, or shadow.
- Real Wayland captures of System Settings and Info Center: dark Transparent
  sidebar/content RGBA both (37, 37, 42, 184), light Transparent both
  (243, 243, 245, 184). System Settings Light Solid matches at
  (242, 243, 245, 255); Info Center Dark Solid at (37, 38, 41, 255).
- Preview validation now compares sidebar and content RGB as well as alpha.
  Toolbar alpha remains 255. Captures were visually inspected.
- Discover Dark Transparent regression passes: three opaque cards, 46 contained
  sidebar selection/hover surfaces, opaque drawer, and page alpha 184.
- Quick launcher installation, refresh, stale-version fallback, edit protection,
  argument forwarding, and restoration checks pass. Updated overlay installed.

## Canvas and titlebar tint matching (2026-09-20)

- Controlled native Wayland compositor captures over a uniform RGB (64, 96, 128)
  backdrop exposed a mismatch invisible in raw `grabWindow()` RGBA captures:
  the translucent Quick clear color appeared white while the titlebar appeared
  RGB (193, 202, 213). Painting the same 184/255 tint as a scene rectangle over
  a transparent native clear color gives RGB (193, 202, 213) in both areas.
  Cropped test windows: [before](preview/tint-composited-before-detail.png) and
  [after](preview/tint-rectangle-detail.png).
- Real Discover's Plasma Widgets category passes native Wayland capture checks:
  solid cards/sidebar, page alpha 184/255, and a full-window scene tint with a
  transparent native clear color. Dark Transparent System Monitor also passes.
- Solid Discover retains fully opaque canvas, cards, sidebar, and native clear
  color. Preview checks now assert the scene tint's size and alpha separately
  from the native window clear color. Decoration checks compare titlebar RGBA
  against the selected material's Window palette.
- Quick install/refresh, system-module version fallback, edited-launcher
  protection, and restoration checks pass. Refreshed the installed overlay.

## System Settings canvases and dialog blur (2026-09-20)

- Real System Settings on Wayland: light Transparent canvas alpha 184/255,
  sidebar/header 255/255; dark Transparent also passes at 150% scale. Solid
  canvas/sidebar/header all remain 255/255. Captures were visually inspected.
- The actual Colors KCM grid page also measures 184/255 on its unframed canvas.
  Canvas checks now reject zero-size settings pages and detect stacked tint
  (formerly 235/255), rather than merely checking for some transparency.
- A Wayland protocol trace confirms `ext_background_effect_surface_v1.set_blur_region`
  requests on the System Settings surface. KWin reports its Blur effect loaded.
- `verify-window-materials.py` interposes only the KWindowEffects call in an
  isolated test process. It verifies actual style requests and pixel alpha for
  parented/unparented dialogs, tool windows, popups, masks, reopening, Quick
  surface recreation without native controls, switching to opaque Quick colors,
  embedded scenes, and style cleanup. Generic, Konsole, and Dolphin app identities
  pass. This test checks requests; the separate Wayland trace checks delivery.
- Discover retains solid card/sidebar surfaces with canvas alpha 184. Existing
  toolbar/scrolling/docking/RTL checks and Quick install/restore checks pass.
- Full System Settings still crashes during offscreen platform initialization;
  its working native Wayland path is used for validation. Offscreen embedded
  KCMs can produce an empty ColumnView; the preview now detects that condition.
- Installed the compiled plugin and refreshed the existing Quick launchers.
  Installed/staged plugin hashes match. Backup location is in `DEPLOYMENT.md`.

## Plasma artwork and color schemes

- All 44 SVGs load through QtSvg and have unique element IDs.
- KSvg rendered light and dark component previews; corners, shadows, highlights,
  and surface transparency were visually inspected.
- Desktop widget backgrounds include the `blurred` and `blurred-mask` frames
  required by Plasma's installed BasicAppletContainer. The blurred surface uses
  a 32% white tint in light mode and 50% charcoal tint in dark mode, with a 16px
  corner radius and matching rounded mask. White rims use 50%/22% opacity. Solid and
  opaque variants retain their unblurred fallback.
- The glass comparison renders actual generated KSvg frames over a sample
  wallpaper using Qt Quick's accelerated blur. Example controls illustrate the
  material; individual widgets retain their own control styling.
- Normal surfaces use 76% opacity; translucent surfaces use 64%. Opaque and solid
  fallbacks remain opaque. Shadow interiors stay transparent, and corner/edge
  alpha matches within 2/255 at their joins.
- Task states retain compact insets and distinguish focused, running, minimized,
  and idle pinned apps. Expanded panel widgets use neutral gray/white highlights.
- Both Global Theme IDs match their package names. Their defaults reference the
  generated color schemes, Plasma styles, independent application style and
  decoration, and bundled splash. They do not replace icons or panel layouts.

## Application style and decoration

- The source copy is separate from `~/Darkly`, excludes its Git history, retains
  its upstream license/copyright notices, and uses independent names/settings.
- Release builds of the Qt 6 style, configuration modules, settings application,
  and KDecoration3 plugin completed successfully.
- `QStyleFactory.create('SequoiaEleven')` succeeds. Real Qt widget galleries were
  rendered in both light and dark palettes, including tabs, fields, buttons,
  checkboxes, a slider, table, and progress indicator.
- KDE's native decoration preview engine successfully loads
  `org.kde.sequoiaeleven`. Its light/dark previews show rounded frames, shadows,
  centered captions, and colored controls. The sample preview engine supplies
  its own button arrangement; live activation configures close/minimize/maximize
  on the left.
- The title bar now reserves two small-spacing units above the caption and
  controls (previously one). Border height, caption position, and button offsets
  share this metric, including screen-edge button hit areas. The rebuilt plugin
  renders successfully in both native decoration previews using the current
  Adwaita Sans title font. This padding update is staged; system installation
  requires `sudo cmake --install build/desktop`.

## Floating application islands

- The updated Qt 6 plugin builds and stages successfully. Light and dark previews
  use the staged plugin with isolated configuration and show an actual toolbar,
  dock sidebar, and inset table alongside the existing widget gallery.
- Toolbars, docked panels, and framed views use 5px surface insets, up to 14px
  corner radii, a fine outline, and soft shadows. Content frames reserve 12px
  around child viewports. Standalone KDE-marked frameless navigation lists gain
  a frame; lists inside docks share the dock's surface.
- `python3 tools/verify-application-islands.py` passes for toolbar clicks,
  overflow access, scrolling to the last item, narrow windows, RTL layout,
  vertical/stacked toolbars, dock detach/reattach, and restoring style-owned
  margins/frames when switching to Fusion. It also passes at 150% scale.
- Offscreen checks do not verify live compositor blur or every application's
  custom sidebar implementation. This update is built and staged locally;
  the installed system plugin requires reinstalling and restarting applications.

## Qt Quick/Kirigami application islands

### Locked Okular sidebar containment

- Reproduced Okular's locked sidebar with a generated PDF in an isolated session.
  Its zero-height custom dock title caused Qt to ignore the dock's top margin,
  leaving the tab strip above the theme's inset surface. The style now reserves
  the missing top space inside the content layout after Qt positions the dock.
- The real window now places the tab strip 12px below the dock's top, inside the
  surface's 5px inset. Regression checks cover narrow and RTL layouts, floating
  and re-docking, and restoration of original content margins on style changes.
- Captures: `preview/okular-sidebar-before.png` and
  `preview/okular-sidebar-fixed.png`, with widget geometry trees alongside them.

- Generated local overrides from the installed KDE components. Drawers and page
  headers use 5px insets, 14px corners, subtle rims, and shadows; cards use matching
  corners. Framed scroll views reserve 12px for content. System Monitor's
  zero-margin table receives padding, and System Settings' navigation/form pages
  receive explicit floating scroll surfaces.
- Captured real System Monitor windows in light/dark mode using accelerated
  offscreen rendering. Native pointer clicks selected Applications and returned
  to Overview; this also passed with RTL layout at 150% scale.
- Discover and System Settings loaded the shared overrides and were visually
  checked on Wayland in temporary, automatically closed test windows. System
  Settings' touchpad module crashes with the offscreen platform before loading
  the UI, so its preview must use `--platform wayland`. Discover's accelerated
  offscreen capture showed artifacts; its final capture also uses Wayland.
- Discover's custom drawer now reserves 12px around its navigation viewport and
  scrollbars, keeping hover and selection surfaces inside the 5px island border.
  The real-app preview checks all 46 sidebar style surfaces against the border;
  this passed in light mode and in dark mode with RTL layout at 150% scale.
- `python3 tools/verify-quick-islands.py` verifies installation, refresh, paths
  containing spaces, argument forwarding, import-path precedence, fallback after
  source changes, protection of subsequently edited launchers, and exact restore.
- Installed user-local launchers for System Monitor, System Settings, and Discover,
  including their desktop actions. No global QML environment override or system
  component replacement is used. New menu launches load the extension; existing
  instances must be fully closed first.
- The generic components do not override every application-defined layout. In
  particular, apps can choose their own drawer content spacing. GTK, Electron,
  and sandboxed runtime copies are not covered. All settings pages and app
  workflows have not been exhaustively exercised.

## Solid and Transparent application variants (2026-09-20)

- All six selectable schemes, the bundled legacy palette, and the embedded
  Plasma palettes now set `[KDE] frameContrast=0`. KDE's native
  `KColorScheme::frameContrast()` confirms 0.000 for each scheme. Normal and
  alternate view backgrounds match their window equivalents in RGB; content
  views are opaque while Transparent canvases use 184/255 alpha. Style-owned island/card rims and
  decorative window/widget outlines honor zero contrast.

- Generated and staged Light/Dark × Solid/Transparent color schemes and Global
  Themes. `verify-materials.py` checks a complete installation into a path with
  spaces, pairing each scheme with its decoration and preserving legacy entries.
- Built separate native `org.kde.sequoiaeleven.solid` and
  `org.kde.sequoiaeleven.transparent` decorations from the shared source. Both
  follow the active light/dark colors and retain the existing controls/geometry.
  Native decoration previews measured titlebar alpha 255 for Solid and 184 for
  Transparent in both palettes.
- Real Qt widget captures measured Solid canvas/toolbars/sidebars at alpha 255;
  Transparent canvas at 184 and toolbar/sidebar/content/group/tab-page interiors
  at 255 in both light and dark palettes. Surface painting is independent of
  window alpha; transparent preset islands also ignore legacy bar/sidebar opacity.
  Text/button palette colors remain opaque. Material presets do not overwrite
  the user's custom legacy style configuration.
- Real Discover captures confirmed page alpha 184 and solid drawer/header surfaces
  (254–255 after scene-graph rendering), with Solid measuring 255 throughout.
  Discover and System Monitor card interiors measure 255. The preview checks
  allow one alpha step for scene-graph rounding. The 46 sidebar selection/hover surfaces remain inside
  the border. Quick windows request alpha buffers before creation and compositor
  blur when their background is translucent.
- The earlier Transparent implementation passed native Wayland widget rendering
  and Discover RTL at 150%. This solid-island update passes light/dark native-scale
  previews, including Discover RTL. Its offscreen OpenGL capture at 150% produced
  an incomplete frame (missing drawer pixels); fractional-scale rendering of the
  updated Quick layer still needs a live desktop check.
- Installation/restoration, source-version fallback, toolbar clicks/overflow,
  scrolling, RTL, stacked/vertical toolbars, dock transitions, and style cleanup
  checks pass. Login palette selection recognizes all four material scheme names.
- Application-defined opaque content can still cover the transparent background.
  Compositor blur depends on KWin's Blur effect. GTK/Electron and isolated Flatpak
  runtimes do not inherit the native Qt implementation.

## Typography

- Adwaita Sans upright/italic variable fonts were copied unmodified from the
  installed Fedora package, including its SIL OFL license. The bundled source
  manifest records the package, source paths, upstream project, and checksums.
  The previously bundled Nunito files remain for clock and splash display text.
- Qt resolves real Adwaita Sans regular, medium, semibold, bold, and italic faces;
  required menu text, digits, currency, and punctuation glyphs are present.
- Desktop/menu/toolbar text remains 10pt, small labels 9pt, and window titles
  become 10pt medium. The sample menu text grows by about 19px (4.6%) compared
  with Nunito; the comparison preview fits the requested menu labels.
- Fontconfig resolves antialiasing enabled, slight hinting (1), and grayscale
  rendering (rgba none/5). No font aliases, forced DPI, monospace substitutions,
  panel geometry, or menu spacing changes are introduced.
- The focused font installer snapshots the prior KDE/GTK settings, font rule,
  installed fonts, and installed theme defaults. Staged settings were diffed
  before applying; unrelated theme preferences are preserved.

## Lock screen

- The redesigned shell loaded in the actual greeter's **offscreen testing mode**.
  Its journal was checked for missing components and QML type/reference errors.
- A captured 800×800 preview exercises the clock, avatar, password field, steady
  unlock/session actions, footer, and media card with sample album artwork.
- A dedicated integration check on an **isolated D-Bus session** discovered a mock
  MPRIS player, displayed its track/artist and playback state, and verified that
  Previous, Play/Pause, and Next reach the player in order. Real players were not
  controlled by this test.
- The original Plasma authentication and password synchronization handlers are
  retained. Interactive authentication, fingerprint, and smartcard flows were
  not exercised by the visual test.
- The password row is capped at 360px, with a 36px-high field and matching
  36px-square unlock button. The media card is 392×156px (previously 432×174px),
  centered below the field with 64px artwork and 36px-high playback controls.
- The password field has a constant 1px antialiased white border at 70% opacity.
  The avatar is 6 grid units across, with extra list height preserving label spacing.
- Separate light/dark greeter previews use isolated settings, without changing
  the active desktop. The media card follows the Window palette independently
  of the lock screen's Complementary palette: pale background/dark text in light
  mode, charcoal background/light text in dark mode. Both loaded without QML
  errors, and MPRIS discovery and playback checks passed after the resize.
- The lock-screen copy must be refreshed with the installer after Plasma updates.

## System Settings usage history diagnosis (2026-09-20)

- The empty “Most used pages” section reproduced with both stock Breeze and
  Sequoia Eleven in the real Quick Settings KCM. Its repeater had zero entries;
  the styling was not hiding any delegates.
- The activity database contained history for 32 System Settings pages, but the
  live KDE ActivityManager returned an empty current activity despite listing
  the existing Default activity. Selecting Default in an isolated session with
  a copy of that database restored the page buttons under the custom styling.
- Restored the existing Default activity through ActivityManager's supported
  `SetCurrentActivity` method and verified `CurrentActivity` returned its ID.
  No application-style patch or history-database edit was needed.
- Full offscreen System Settings startup hit an unrelated crash in the installed
  touchpad module; the comparison used `kcmshell6 kcm_landingpage` to run the same
  landing page without loading unrelated settings modules.

## Adaptive wallpaper

- Original preview geometry and colors are preserved in editable SVG sources,
  with matching 3840×2160 light/dark PNGs in one `Wallpaper/Images` package.
- Plasma's native `MediaProxy`, running offscreen on an isolated D-Bus session,
  resolved the light, dark, and automatic package URLs to the expected bundled
  images. The automatic URL has no forced-color or day/night fragment; installed
  Plasma configuration documents this as following the active color scheme.
- Both Global Themes reference `SequoiaEleven` in their wallpaper defaults.
  The full desktop installer applies the package and snapshots the previous
  desktop wallpaper configuration; `--keep-wallpaper` skips activation.
- Artwork installation and reinstallation passed in an isolated prefix with
  spaces. PNG decoding, package metadata, defaults, shell/Python syntax, and
  wallpaper/source archive contents were checked. No live desktop was changed;
  a live color-scheme transition and multi-monitor behavior remain untested.

## Merkuro collapsed sidebar — 2026-09-21

- The collapsed width now includes the drawer's left and right island padding;
  the 12px margins no longer consume the navigation icons' available space.
- `preview-quick-islands.py --app merkuro --collapse-sidebar --material transparent`
  passes in light mode. The preview clicks the real collapse control and checks
  that all four navigation icons have usable dimensions and fit inside their
  buttons and every clipping ancestor.
- The same check passes with `--calendar-view tasks --dark --material solid
  --scale 1.5 --rtl`, including navigation to Tasks after collapse. Both captures
  were visually inspected; material opacity and QML error checks also pass.
- Python syntax checks pass for the modified builder and preview tool.

## Native settings sidebar containment — 2026-09-21

- Reproduced the Konsole-style settings list with the installed KDE
  `KPageDialog`: a 91px delegate was clipped by a 78px viewport. KDE's fixed
  list width did not include the theme's 12px content margins on both sides.
- The style now adds only the missing width after viewport layout. The original
  fixed width is restored when switching styles.
- `python3 tools/verify-settings-sidebar.py` and its `--dark --scale 1.5`
  variant pass. The check fails against the original plugin. It verifies complete
  row bounds, navigation clicks, vertical scrolling, RTL, larger fonts, label
  changes, and style cleanup using KDE's real settings widget and delegate.
- Light and dark captures were visually inspected. The existing
  `verify-application-islands.py` interaction and containment checks also pass.

## Deployment and limits

- The activation tool snapshots the affected settings and installed local artwork
  before changing them. A restoration tool restores that snapshot; independently
  named system plugins remain installed but unused after restoring.
- Live activation confirmed: KWin's support information reports
  `Plugin: org.kde.sequoiaeleven`, both Global Themes are listed, and a fresh Qt
  application using KDE platform integration selects `sequoiaeleven`.
- Python tools pass syntax checks. The generated source archive includes the
  application/decoration source and its license, original artwork, lock-screen
  components, and build/install/preview tools.
- Desktop wallpaper blur requires accelerated Qt Quick rendering and a widget
  with StandardBackground. Backgroundless widgets keep their chosen appearance.
- Software previews do not reproduce KWin's native blur. Album artwork falls back
  to an unmasked image in software mode; GPU rendering uses rounded masking.
- Fractional scaling, multiple-monitor lock-screen layout, and all third-party
  widgets still require observation in the live desktop. The application style
  targets Qt 6 widgets; Qt 5, GTK, Electron, browser content, and isolated Flatpaks
  can retain independent application styling.
# Plasma Login appearance — 2026-09-20

- Detected the active display manager as `plasmalogin.service` and checked the
  matching KDE Plasma 6.7 source for supported settings and appearance sync.
- `python3 tools/verify-login.py` passes: inherited KDE defaults, explicit
  light/dark/light switching, matching palettes/fonts, preservation of unrelated
  greeter settings, idempotent writes, and retention when another theme is used.
- Both `tools/preview-login.py --mode light` and `--mode dark` load the installed
  `/usr/libexec/plasma-login-greeter --test` without QML errors and capture the
  real controls. The preview adds only a temporary capture hook and wallpaper
  backdrop; authentication is mocked and power operations are unavailable in
  the isolated offscreen session. Preview PNGs were visually inspected.
- Python compilation and `systemd-analyze verify` pass for the new tools/units.
- System installation completed through administrator authentication, with
  backup `/var/backups/sequoia-eleven-login/20260920-082042-917532`.
- The path unit is enabled and active (waiting). The oneshot service is enabled,
  completed with `0/SUCCESS`, and reports `Sequoia Eleven Light`, matching the
  desktop. Installed helper and palettes are root-owned, mode 0644.
- `/etc/plasmalogin.conf` selects the globally readable adaptive wallpaper
  package and native image plugin. Adwaita Sans resolves through fontconfig.
- No live login, logout, authentication attempt, or display-manager restart was
  performed. The next greeter startup is the remaining real-session visual check.


## System tray Control Center — 2026-09-21

- Installed a user-local dashboard for the existing tray; the panel's application
  icons and widget IDs are preserved. The overflow arrow is now a sliders icon.
- The deterministic QML fixture passes Space-key activation for Wi-Fi, Bluetooth,
  Do Not Disturb, microphone mute, speaker mute and play/pause. Keyboard volume
  changes reach the backend, and later external volume updates still reach the slider.
- Dark rendering and light rendering with larger text/RTL were captured using the
  GPU renderer. The live backend preview initializes without dashboard QML errors.
- The actual system tray, hosted by plasmawindowed with a temporary configuration
  and private bus, opens the dashboard, navigates to native audio details and
  returns to the dashboard successfully. No actual hardware toggles or session
  actions are invoked by automated tests.
- Hardware availability is explicit. PowerDevil must expose an adjustable display
  for a brightness slider. The native device pages remain accessible.
- A version-checked launcher scopes the entry-point helper to plasmashell and
  falls back to the normal tray after a Plasma library/plugin change. Installation
  and removal are documented in README.md and plasma/control-center/README.md.

## Control Center detail menus — 2026-09-22

- Native audio, brightness, battery, Bluetooth, network, notifications,
  clipboard, removable-device, printer and camera pages open with the new
  surfaces and return to the compact dashboard. Their existing models and
  actions remain native; tests do not change hardware settings.
- Light and dark/13pt/RTL captures verify page sizing and surface colors,
  including the audio page's first-open background palette.
- Clipboard opens a sample barcode and invokes its native Back action before
  returning home. No clipboard content is changed by this check.
- Existing tray visibility-policy tests and native media tabs/artwork/Back
  regression checks pass. Python installer/check scripts compile successfully.
- Native checks isolate configuration, data, cache, state and session D-Bus.
  They register a dummy PowerDevil service name solely to load power/brightness
  pages; actual power services and hardware mutations are not exercised.
- Installed files and source fingerprints match the staged build. Multi-display
  brightness delegate construction now checks neighboring items before linking
  keyboard navigation, avoiding an upstream startup null dereference.

## Weather floating cards — 2026-09-22

- Day and night have separate padded forecast cards; a daily-only provider uses
  one card with both high and low temperatures. The native weather backend and
  unit conversion remain intact.
- Current conditions, details and notices have rounded card surfaces. Notice
  text wraps within 16px padding; the outer viewport scrolls long pages.
- Light and dark/13pt/RTL fixtures pass table dimensions, tab switching, card
  content bounds, zero-valued details, daily-only, and unavailable/loading checks.
- The real KDE weather applet loads through the staged tray and returns to the
  dashboard. The installed overlay matches the stage; the reloaded shell reports
  no Control Center QML errors. Fixtures use sample data and no weather requests.

## Contacts menu — 2026-09-22

- Native Merkuro applet entry point and backend imports retained; only the exact
  Merkuro entry URL joins the managed bridge and plugin fingerprint manifest.
- Sample-data checks cover filtering, no results, keyboard open, long profile
  fields, QR sharing and search retention after Back in light and dark/large/RTL.
- Hardware-rendered dark preview confirms monochrome action icon contrast.
- All twelve native menus and Back navigation pass, including two nested
  Contacts pages. Native checks use a separate Akonadi instance; sample profile
  data is injected into the view instead of fetching a nonexistent contact ID.
- Installed overlay bytes and plugin fingerprints match the verified stage.

## Desktop repair (2026-09-23)

See [desktop repair findings and validation](DESKTOP-REPAIR.md) for Tahoe app
aliases, Activity restoration, the Contacts login hang fix and preview isolation.

## Control Center icon animation (2026-09-23)

Added hover and popup-state slider motion, using Kirigami animation durations.
Installed the icon and expander binding after verifying intermediate animation
values, endpoints and Wayland renders. The native tray/dashboard/navigation
check passes. Plasma was restarted to load the update.

## Search focus border (2026-09-23)

The native Plasma TextField expands its hover/focus overlay by the SVG frame
margins. Added prefix-specific `hint-no-border-padding` to the line-edit hover,
focus and keyboard-focus frames in both theme variants. The base keeps 6px text
padding. This also corrects other native Plasma text fields using these assets.
The generator preserves the change. Native SearchField renders verify exact
overlay/base alignment in Light and Dark (`preview/search-highlight-*.png`).
Installed the two SVGs with backups under `.staging/before-search-highlight-*`
and restarted Plasma.

KSvg's [frame implementation](https://github.com/KDE/ksvg/blob/master/src/ksvg/framesvg.cpp)
supports this hint per prefix; zero-size margin rectangles are invalid and fall
back to the artwork's border size.

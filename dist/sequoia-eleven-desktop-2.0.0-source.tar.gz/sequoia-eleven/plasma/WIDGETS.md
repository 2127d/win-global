# Sequoia widget archives

`~/sandbox/widgets` contains exactly these five files:

- `downloads.tar.gz`
- `separator.tar.gz`
- `icons-only-task-manager-animated.tar.gz`
- `system-tray.tar.gz`
- `install-widgets.py`

## Install

Copy the folder to the destination account, open a terminal there, and run:

```sh
cd ~/sandbox/widgets
python3 install-widgets.py
```

The script scans the **current directory** for widget archives, validates their
IDs, entry points and compatibility, and asks for sudo to install the package
files system-wide. It installs packages under `/usr/share/plasma/plasmoids/`
and the included native adapters under Qt's system `plugins/plasma/applets/`
directory. It then selects the unified notification fork for your account and
restarts Plasma. No compilation or source checkout is needed for installation.
Do not start the script with sudo: it handles elevation and keeps desktop
settings and the restart in your own session.

Your existing System Tray and Icons-only Task Manager keep their IDs, settings,
positions and pinned applications. Add **Sequoia System Tray** and
**Icons-Only Task Manager Animated** yourself through **Add Widgets** when ready.
**Downloads Stack** and **Dock Separator** are also available there.

The tray archive includes independently named forks of its styled detail widgets,
including Notifications, plus the styled Trash widget. The installer selects
**Sequoia Notifications** inside existing trays, preserves notification visibility
and disabled states, and keeps existing notification instance settings. The tray
fork selects its own styled children by default. KDE's original widget packages
and libraries are retained.

Previous system files are backed up under `/var/backups/sequoia-widgets/`.
Changed panel settings are backed up beside the user's configuration. Older
user-local copies of the same custom IDs are backed up outside Plasma's applet
folder so they cannot hide the system installation. The recognized legacy
Sequoia control-center service hook is also backed up and retired; original
widgets then use KDE's original presentation, and the custom presentation lives
in the new forks. Unrelated service overrides are retained.

## Compatibility

The native adapters reuse the installed KDE backends, while each fork has its
own ID, QML and configuration schema. There is no shell-wide preload. The tray
and task-manager archives contain compiled adapters for the build machine's
architecture and Qt/KDE versions. The installer checks Qt and upstream file
fingerprints **before making changes** and rejects incompatible archives.
These packages were built on Fedora 44 with Plasma 6.7.5 and Qt 6.11.2.
Rebuild the archives after relevant KDE updates or for another supported machine.
The pure QML Downloads and Separator packages do not need native adapters.

Use the supplied script for the full collection: Plasma's local-file widget
installer alone cannot install the native adapter libraries in the other two
archives. Installing the theme/icons is separate.

Validate without installing:

```sh
python3 install-widgets.py --check
```

Stage system files without sudo or changing a desktop:

```sh
python3 install-widgets.py --prefix /tmp/sequoia-widget-stage
```

## Development

The editable source and build tools remain in `win-global`. Rebuild and replace
the export with:

```sh
python3 tools/export-widgets.py --destination ~/sandbox/widgets
```

The old export is preserved as a sibling timestamped backup. The exported folder
contains only the four archives and the installer. Each archive includes its
editable QML, native adapter source where needed, and license notices.
`tools/build-widget-forks.py` builds the archives; `tools/install-widget-archives.py`
is the source of the exported installer. `plasma/widget-forks/native-factory.cpp`
provides the normal applet factory used by the native forks. The customization
sources and checked upstream transformations remain under `plasma/control-center/`
and `tools/control_center_*.py`.

Build dependencies are the existing theme/widget development dependencies,
including PySide6, Qt 6 development tools, a C++ compiler and KF6 CoreAddons
headers. Installation needs Python 3.12 or newer, Plasma 6, `qtpaths6`, sudo and
a systemd user session.

Verify staging, notification configuration, fork loading, task settings and
notification delivery:

```sh
python3 tools/verify-widget-archives.py --folder ~/sandbox/widgets --functional
```

KDE source files retain their copyright and SPDX notices; license texts are
included in each derived package. Sequoia's original additions are MIT licensed.

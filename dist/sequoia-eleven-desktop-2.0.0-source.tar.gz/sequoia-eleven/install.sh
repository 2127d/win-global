#!/usr/bin/env bash
set -euo pipefail

source_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
data_dir="${XDG_DATA_HOME:-$HOME/.local/share}"

if [[ "${1:-}" == "--help" ]]; then
    printf '%s\n' 'Usage: ./install.sh [--prefix DATA_DIRECTORY]' 'Installs Plasma styles, Solid/Transparent Global Themes, Sequoia Tahoe icons, color schemes, and the light/dark wallpaper without changing your active theme. Build and install the native plugins separately with tools/build-desktop.sh and cmake --install.'
    exit 0
fi
if [[ "${1:-}" == "--prefix" && $# == 2 && -n "$2" ]]; then
    data_dir="$2"
elif [[ $# != 0 ]]; then
    printf '%s\n' 'Invalid arguments. See ./install.sh --help.' >&2
    exit 2
fi

mkdir -p -- "$data_dir/plasma/desktoptheme" "$data_dir/plasma/look-and-feel" "$data_dir/color-schemes" "$data_dir/wallpapers" "$data_dir/icons"
cp -R -- "$source_dir"/icons/SequoiaTahoe* "$data_dir/icons/"
if command -v gtk-update-icon-cache >/dev/null 2>&1; then
    for theme in "$data_dir"/icons/SequoiaTahoe*; do
        gtk-update-icon-cache --force --ignore-theme-index "$theme"
    done
fi
cp -R -- "$source_dir/wallpapers/SequoiaEleven" "$data_dir/wallpapers/"
for variant in light dark; do
    cp -R -- "$source_dir/plasma/desktoptheme/sequoia-eleven-$variant" "$data_dir/plasma/desktoptheme/"
done
cp -- "$source_dir"/color-schemes/SequoiaEleven*.colors "$data_dir/color-schemes/"
cp -R -- "$source_dir"/plasma/look-and-feel/org.sequoia.eleven.* "$data_dir/plasma/look-and-feel/"
printf 'Installed Sequoia Eleven to %s\nChoose Light/Dark Solid or Transparent in System Settings → Colors & Themes → Global Theme.\nChoose Sequoia Eleven in Wallpaper settings for automatic light/dark switching based on the color scheme.\n' "$data_dir"
